# Clips para el hero de USA Latino Prime

Cinco escenas de **6 segundos**: 30 segundos por recorrido. Generar cada escena dos veces, usando su primera toma horizontal y vertical respectivamente. Son imágenes de marca generadas, no testimonios ni casos reales. El logo, titular, botones y efecto de la estrella se añaden en la web: los videos deben salir limpios.

| Orden | Archivo base | Servicios representados |
| --- | --- | --- |
| 01 | juvenil-desktop / juvenil-mobile | Visa Juvenil SIJS y Petición I-360 |
| 02 | residencia-desktop / residencia-mobile | I-485, Ajuste de Estatus |
| 03 | asilo-desktop / asilo-mobile | Asilo Político y Reforzar Asilo |
| 04 | corte-desktop / corte-mobile | Apelación BIA y Cambio de Corte |
| 05 | impuestos-desktop / impuestos-mobile | ITIN y Declaración de Impuestos |

Las imágenes completas para Grok están en `docs/hero-services-originals/`. Las versiones WebP utilizadas en la página están en `public/hero-services/`. Los originales conservan el formato generado: aproximadamente 16:9 horizontal y 9:16 vertical.

## Instrucción común

Usar esta instrucción más el movimiento de cada escena. En móvil conservar especialmente el encuadre de la acción en la parte superior. Generar cada clip a partir de su imagen correspondiente.

> Use the provided image as the exact first frame of a continuous 6-second cinematic shot. Preserve the composition, every person's identity, clothing, lighting, objects, deep navy and restrained gold color palette. Keep all important subjects in their original part of the frame; preserve the dark negative space for website text. Natural restrained movement, anatomically correct hands and stable faces. No cuts, no transitions, no camera shake, no new people or objects, no invented text, no captions, no logos, no added approval stamps or cards. Keep the input aspect ratio. No music or dialogue needed. End with a stable half-second for the website transition.

## 01 · Visa Juvenil y Petición I-360

> The case assistant gently moves the pen along one line of the open file. The young adult follows the gesture with his eyes and gives a very small nod. His guardian remains quietly beside him. A subtle slow camera push-in, almost imperceptible. Do not turn the page, change facial expressions dramatically, move the hands extensively, or turn anyone toward camera.

## 02 · Ajuste de Estatus

> Slow macro camera movement toward the organized application folder. The woman's fingers lift the existing folder cover just slightly and then remain still. A soft highlight travels across the paper as the camera moves. Preserve all existing documents and the closed passport exactly, without transforming them into identity cards or generating readable text. No new documents and no approval outcome.

## 03 · Asilo y Reforzar Asilo

> A very slow lateral camera movement during a calm confidential case-preparation conversation. The case assistant gives a small attentive nod; the woman makes a subtle natural breathing movement and looks briefly toward the open file. Maintain the respectful serious mood. No speaking, dramatic sadness, tears, smiles of victory, paperwork changes or extra hand gestures.

## 04 · Apelación BIA y Cambio de Corte

> The person holding the case folder takes one slow natural step toward the civic building entrance. Camera follows with a gentle upward-and-forward movement of only a small distance, preserving the architectural composition and the dark left area. Very subtle movement in the jacket. No new passersby, altered architecture, readable signs, police, judges, flags, or courtroom victory imagery.

## 05 · ITIN y Declaración de Impuestos

> The tax preparer gently slides a single existing receipt a few centimeters beside the calculator, while the business owner observes. Slight slow camera push-in toward the organized desk. Keep the forms, laptop and calculator stable, with no readable invented text, screen animation or newly appearing objects. Correct natural fingers, one simple small gesture only.

## Entrega de los videos

Diez clips MP4: `juvenil-desktop.mp4`, `juvenil-mobile.mp4`, `residencia-desktop.mp4`, `residencia-mobile.mp4`, `asilo-desktop.mp4`, `asilo-mobile.mp4`, `corte-desktop.mp4`, `corte-mobile.mp4`, `impuestos-desktop.mp4`, `impuestos-mobile.mp4`.

El hero actual usa las primeras tomas, animación suave y cambio de capítulo cada 6000 ms. El cliente puede pausar o seleccionar un grupo y entrar al servicio concreto. Se detiene al salir del área visible o cambiar de pestaña y respeta movimiento reducido. Las fuentes de video están previstas en `lib/hero-scenes.ts` y se habilitarán al recibir los clips reales; no se hacen solicitudes a videos inexistentes.

Generación de imágenes: herramienta integrada `image_gen.imagegen`. Prompts de imagen guardados en `docs/hero-services-image-prompts.json`. Conversión WebP únicamente para reducir peso de transferencia, conservando los PNG originales para la producción de video.
