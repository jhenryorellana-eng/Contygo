import type { NextRequest } from "next/server";
import { confirmContract } from "@/lib/contygo-api/flow";
import { checkLimits, clientIp, fail, guarded, json, loadCheckout, readBrowserJson } from "@/lib/contygo-api/server";

// «Contratar», 2.ª llamada: el mismo cuerpo guardado + el código de 6 dígitos.
// La respuesta lleva la signingUrl SOLO para el botón de esta persona: no se registra.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  return guarded(async () => {
    const parsed = await readBrowserJson(req);
    if ("response" in parsed) return parsed.response;
    const limitedIp = await checkLimits([{ key: `confirm:ip:${clientIp(req)}`, windowSeconds: 3600, max: 30 }]);
    if (limitedIp) return limitedIp;
    const session = await loadCheckout(req);
    if (!session) return fail("no_session", 409);
    const limited = await checkLimits([{ key: `confirm:s:${session.id}`, windowSeconds: 900, max: 10 }]);
    if (limited) return limited;

    const outcome = await confirmContract(session.id, session.stored.state, parsed.body.code);
    const headers: Record<string, string> = outcome.step === "RETRY_LATER" && outcome.retryAfter ? { "Retry-After": String(outcome.retryAfter) } : {};
    return json({ ok: true, outcome }, 200, headers);
  });
}
