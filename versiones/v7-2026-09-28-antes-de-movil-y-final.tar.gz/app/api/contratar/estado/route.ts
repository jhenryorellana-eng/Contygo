import type { NextRequest } from "next/server";
import { contygoApi } from "@/lib/contygo-api/client";
import { fail, guarded, json, loadCheckout, readBrowserJson, updateCheckout } from "@/lib/contygo-api/server";

// Página de «gracias» y red de seguridad si un webhook no llegó: GET /contracts/{id}.
// contygo pide no consultarlo más de una vez por minuto por contrato: se guarda 60 s.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const FRESH_MS = 60_000;

export async function POST(req: NextRequest) {
  return guarded(async () => {
    const parsed = await readBrowserJson(req);
    if ("response" in parsed) return parsed.response;
    const session = await loadCheckout(req);
    const contract = session?.stored.state.contract;
    if (!session || !contract) return fail("no_contract", 404);

    let state = session.stored.state;
    if (!state.lastStatus || Date.now() - Date.parse(state.lastStatus.at) >= FRESH_MS) {
      const response = await contygoApi.getContract(contract.contractId);
      if (response.status === 200 && response.data) {
        const value = response.data;
        state = (await updateCheckout(session.id, current => ({ ...current, lastStatus: { at: new Date().toISOString(), value } }))).state;
      } else if (!state.lastStatus) {
        return fail("status_unavailable", response.status === 429 ? 429 : 502, { retryAfter: response.retryAfter });
      }
    }
    const status = state.lastStatus?.value;
    const events = state.events ?? {};
    // Sin PII y sin URL de firma: solo lo que la página necesita para decir en qué punto está.
    return json({
      ok: true,
      caseNumber: contract.caseNumber,
      clientCreated: contract.clientCreated,
      contract: status?.status === "signed" || events.contractSignedAt ? "signed" : status?.status ?? "sent",
      signingExpiresAt: status?.signingExpiresAt ?? null,
      downpayment: events.downpaymentConfirmedAt ? "paid" : status?.downpayment.status ?? "pending",
      checkedAt: state.lastStatus?.at ?? null,
    });
  });
}
