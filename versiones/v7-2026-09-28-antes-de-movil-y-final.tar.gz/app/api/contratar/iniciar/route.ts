import type { NextRequest } from "next/server";
import { startContract } from "@/lib/contygo-api/flow";
import { checkLimits, clientIp, fail, guarded, json, loadCheckout, readBrowserJson, verifyCaptcha } from "@/lib/contygo-api/server";

// «Contratar», 1.ª llamada: contygo envía el código al correo. CAPTCHA y límites propios
// (por IP y por sesión) van delante: la web es pública y cada envío escribe a un buzón real.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: NextRequest) {
  return guarded(async () => {
    const parsed = await readBrowserJson(req);
    if ("response" in parsed) return parsed.response;
    const ip = clientIp(req);
    const limitedIp = await checkLimits([{ key: `start:ip:${ip}`, windowSeconds: 3600, max: 10 }]);
    if (limitedIp) return limitedIp;
    const session = await loadCheckout(req);
    if (!session) return fail("no_session", 409);
    const limited = await checkLimits([{ key: `start:s:${session.id}`, windowSeconds: 3600, max: 4 }]);
    if (limited) return limited;
    const captcha = await verifyCaptcha(parsed.body.captchaToken, ip);
    if (!captcha.ok) return fail(captcha.code, captcha.code === "captcha_not_configured" || captcha.code === "captcha_unavailable" ? 503 : 403);

    const outcome = await startContract(session.id, session.stored.state, parsed.body.form);
    const headers: Record<string, string> = outcome.step === "RETRY_LATER" && outcome.retryAfter ? { "Retry-After": String(outcome.retryAfter) } : {};
    return json({ ok: true, outcome }, 200, headers);
  });
}
