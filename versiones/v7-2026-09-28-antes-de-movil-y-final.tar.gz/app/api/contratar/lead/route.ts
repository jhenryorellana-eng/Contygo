import type { NextRequest } from "next/server";
import { CONTYGO_SERVICES } from "@/lib/contygo-catalog";
import { normalizePhone } from "@/lib/contygo-api/checkout";
import { sanitizeAttribution, syncLead } from "@/lib/contygo-api/lead";
import { checkLimits, clientIp, ensureCheckout, fail, guarded, json, readBrowserJson, setCheckoutCookie, updateCheckout } from "@/lib/contygo-api/server";

// En cuanto el bot tiene nombre y teléfono: PUT /leads/{externalRef}.
// Si contygo no lo registra, el recorrido sigue: el alta lo vuelve a intentar.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const cleanName = (value: unknown) => typeof value === "string"
  ? value.replace(new RegExp("[^\\p{L}\\p{M} '.-]", "gu"), "").replace(/\s+/g, " ").trim().slice(0, 120) : "";

export async function POST(req: NextRequest) {
  return guarded(async () => {
    const parsed = await readBrowserJson(req);
    if ("response" in parsed) return parsed.response;
    const { body } = parsed;
    const local = CONTYGO_SERVICES.find(service => service.id === body.serviceId);
    if (!local) return fail("invalid_service", 400);
    const fullName = cleanName(body.displayName);
    const phoneE164 = normalizePhone(body.phone);
    if (!fullName) return fail("invalid", 400, { errors: { displayName: "Escribe tu nombre." } });
    if (!phoneE164) return fail("invalid", 400, { errors: { phone: "Escribe un teléfono válido, con código de país si no es de EE. UU." } });

    const limitedIp = await checkLimits([{ key: `lead:ip:${clientIp(req)}`, windowSeconds: 3600, max: 20 }]);
    if (limitedIp) return limitedIp;
    const checkout = await ensureCheckout(req, local.id, local.slug);
    const limited = await checkLimits([{ key: `lead:s:${checkout.id}`, windowSeconds: 600, max: 6 }]);
    if (limited) return limited;

    const attribution = sanitizeAttribution(body.attribution);
    const saved = await updateCheckout(checkout.id, state => ({ ...state, ...(attribution ? { attribution } : {}) }));
    const result = await syncLead(checkout.id, saved.state, { fullName, phoneE164 });
    // Se guarda aunque contygo falle: la ficha lo precarga y el alta vuelve a registrar el lead.
    await updateCheckout(checkout.id, state => ({ ...state, lead: { fullName, phoneE164, ...(result.ok ? { leadId: result.leadId } : {}), at: new Date().toISOString() } }));
    const response = result.ok ? json({ ok: true }) : fail("lead_not_registered", 502, { code: result.code });
    if (checkout.created) setCheckoutCookie(response, checkout.id);
    return response;
  });
}
