import type { NextRequest } from "next/server";
import { isTrustedSigningUrl } from "@/lib/contygo-api/checkout";
import { contygoApi } from "@/lib/contygo-api/client";
import { checkLimits, fail, guarded, json, loadCheckout, readBrowserJson, updateCheckout } from "@/lib/contygo-api/server";

// «No me llegó el enlace»: POST /contracts/{id}/link con una Idempotency-Key nueva por reenvío.
// contygo lo manda también por correo, app y push; aquí la URL solo vuelve al botón.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  return guarded(async () => {
    const parsed = await readBrowserJson(req);
    if ("response" in parsed) return parsed.response;
    const session = await loadCheckout(req);
    const contract = session?.stored.state.contract;
    if (!session || !contract) return fail("no_contract", 404);
    // contygo permite 5 por hora y contrato: aquí, 3.
    const limited = await checkLimits([{ key: `resend:s:${session.id}`, windowSeconds: 3600, max: 3 }]);
    if (limited) return limited;

    const reserved = await updateCheckout(session.id, state => ({ ...state, resends: state.resends + 1 }));
    const response = await contygoApi.resendSigningLink(contract.contractId, `reenvio-${contract.contractId}-${reserved.state.resends}`);
    if (response.status === 200 && response.data && isTrustedSigningUrl(response.data.signingUrl)) {
      return json({ ok: true, outcome: { step: "SIGN_LINK", signingUrl: response.data.signingUrl, expiresAt: response.data.expiresAt, rotated: response.data.rotated } });
    }
    const code = response.error?.code ?? `HTTP_${response.status}`;
    if (code === "CONTRACT_ALREADY_SIGNED") return json({ ok: true, outcome: { step: "ALREADY_SIGNED" } });
    if (code === "CONTRACT_NOT_RESENDABLE") return json({ ok: true, outcome: { step: "NOT_RESENDABLE" } });
    if (response.status === 429 || response.status === 503) {
      return json({ ok: true, outcome: { step: "RETRY_LATER", retryAfter: response.retryAfter } }, 200, response.retryAfter ? { "Retry-After": String(response.retryAfter) } : {});
    }
    console.warn(`[contygo] reenvío de firma: ${code}`);
    return json({ ok: true, outcome: { step: "ERROR", code } });
  });
}
