import type { NextRequest } from "next/server";
import { CONTYGO_SERVICES } from "@/lib/contygo-catalog";
import { publicServiceView, remoteServiceFor } from "@/lib/contygo-api/catalog";
import { checkLimits, clientIp, fail, guarded, json, loadCheckout, readBrowserJson } from "@/lib/contygo-api/server";
import { CONTRACT_TERMS } from "@/lib/contygo-api/terms";

// La ficha pide aquí el servicio tal como lo vende contygo (paquetes, pagos, personas)
// y el estado de ESTA conversación. Solo el mismo origen, y solo el dueño de la cookie.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  return guarded(async () => {
    const parsed = await readBrowserJson(req);
    if ("response" in parsed) return parsed.response;
    const limited = await checkLimits([{ key: `svc:ip:${clientIp(req)}`, windowSeconds: 600, max: 60 }]);
    if (limited) return limited;
    const local = CONTYGO_SERVICES.find(service => service.id === parsed.body.serviceId);
    if (!local) return fail("invalid_service", 400);
    const remote = await remoteServiceFor(local.id);
    if (!remote) return fail("service_not_contractable", 404);

    const found = await loadCheckout(req);
    const state = found && found.stored.state.localServiceId === local.id ? found.stored.state : null;
    return json({
      ok: true,
      service: publicServiceView(remote),
      session: {
        answered: Boolean(state) && remote.eligibilityQuestions.every(question => state!.answers?.[question.id] !== undefined),
        eligible: state?.eligibility?.result.eligible ?? null,
        caseNumber: state?.contract?.caseNumber ?? null,
        prefill: state?.lead ? { fullName: state.lead.fullName, phone: state.lead.phoneE164 } : null,
      },
      terms: CONTRACT_TERMS,
      captchaSiteKey: process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || null,
    });
  });
}
