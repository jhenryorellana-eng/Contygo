import type { NextRequest } from "next/server";
import { getCheckoutStore, StoreUnavailableError } from "@/lib/contygo-api/store";
import { verifyWebhookSignature } from "@/lib/contygo-api/webhook";

// Avisos de contygo: case.created, contract.signed y downpayment.confirmed.
// 1) firma HMAC sobre el cuerpo CRUDO y ventana de ±300 s; 2) dedupe por X-Event-Id;
// 3) 2xx en menos de 10 s. El trabajo del evento es una sola escritura en la base:
//    la tabla de eventos es la cola y su efecto en la sesión se aplica en la misma
//    transacción (ulp_cg_webhook_record). Si la base falla, 503 y contygo reintenta.
// Nunca redirige: un 3xx cuenta como fallo.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const MAX_BODY_BYTES = 64 * 1024;
const empty = (status: number) => new Response(null, { status, headers: { "Cache-Control": "no-store" } });

export async function POST(req: NextRequest) {
  const secret = process.env.CONTYGO_WEBHOOK_SECRET;
  if (!secret) { console.warn("[contygo] webhook sin CONTYGO_WEBHOOK_SECRET"); return empty(503); }
  if (Number(req.headers.get("content-length")) > MAX_BODY_BYTES) return empty(413);
  const raw = await req.text(); // el cuerpo CRUDO, antes de parsear
  if (raw.length > MAX_BODY_BYTES) return empty(413);

  const verdict = verifyWebhookSignature({ raw, timestamp: req.headers.get("x-timestamp"), signature: req.headers.get("x-signature"), secret });
  if (verdict !== "ok") return empty(401);

  const eventId = req.headers.get("x-event-id") ?? "";
  if (!eventId || eventId.length > 200) return empty(400);
  let event: { eventId?: unknown; type?: unknown; occurredAt?: unknown; data?: Record<string, unknown> };
  try { event = JSON.parse(raw); } catch { return empty(400); }
  if (!event || typeof event !== "object" || event.eventId !== eventId || typeof event.type !== "string") return empty(400);

  const data = event.data && typeof event.data === "object" ? event.data : {};
  try {
    const result = await getCheckoutStore().recordWebhook({
      eventId,
      type: event.type,
      externalRef: typeof data.externalRef === "string" ? data.externalRef : null,
      occurredAt: typeof event.occurredAt === "string" ? event.occurredAt : new Date().toISOString(),
      payload: event,
    });
    console.info(`[contygo] webhook ${event.type} ${result === "new" ? "registrado" : "repetido"}`);
    return empty(200);
  } catch (error) {
    console.warn(`[contygo] webhook no registrado: ${error instanceof StoreUnavailableError ? error.code : "internal"}`);
    return empty(503);
  }
}
