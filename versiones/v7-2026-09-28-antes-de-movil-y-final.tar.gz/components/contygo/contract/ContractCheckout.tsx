"use client";

/* Ficha de contratación dentro del recorrido. El bot la presenta al final: datos,
   paquete, personas, casilla de aceptación y CAPTCHA → «Contratar» → código → firma.
   Todo lo delicado vive en el servidor (/api/contratar/*): aquí nunca hay claves,
   ni el sobre de verificación; la URL de firma solo existe en memoria para el botón. */
import { useCallback, useEffect, useId, useMemo, useRef, useState, type ReactNode } from "react";
import type { ContygoService } from "@/lib/contygo-catalog";
import { US_STATES } from "@/lib/agent/visa-intake";
import { text, validateContractForm, type FieldErrors } from "@/lib/contygo-api/checkout";
import { outcomeMessage, serviceAlreadyLiveMessage, type ScreenOutcome } from "@/lib/contygo-api/messages";
import type { PublicServiceView } from "@/lib/contygo-api/catalog";
import s from "./ContractCheckout.module.css";

type Terms = { version: string; es: string; en: string };
type ServiceData = {
  service: PublicServiceView;
  session: { answered: boolean; eligible: boolean | null; caseNumber: string | null; prefill: { fullName: string; phone: string } | null };
  terms: Terms;
  captchaSiteKey: string | null;
};
type Person = { key: number; role: string; firstName: string; middleName: string; lastName: string; dateOfBirth: string };
type Notice = { title: string; detail?: string; tone: "info" | "error" | "success" };
type Result = { clientCreated: boolean; caseNumber: string; signingUrl: string | null; serviceAlreadyLive: string | null; firstName: string };
type Stage = "loading" | "form" | "code" | "done" | "blocked" | "failed";
type ApiOutcome = ScreenOutcome & { errors?: FieldErrors; maskedEmail?: string; caseNumber?: string; signingUrl?: string; role?: string | null; retryAfter?: number | null };

const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });
/** +13055550199 → (305) 555-0199 para mostrarlo; el servidor vuelve a normalizarlo a E.164. */
const displayPhone = (value: string) => /^\+1\d{10}$/.test(value) ? `(${value.slice(2, 5)}) ${value.slice(5, 8)}-${value.slice(8)}` : value;
const cents = (value: number) => money.format(value / 100);
const WHATSAPP = "https://wa.me/17633422258?text=";

declare global {
  interface Window { turnstile?: { render: (el: HTMLElement, options: Record<string, unknown>) => string; reset: (id?: string) => void; remove: (id: string) => void } }
}

/** Cloudflare Turnstile en modo explícito. Cada token vale una vez: se reinicia tras cada envío. */
function useTurnstile(siteKey: string | null) {
  const container = useRef<HTMLDivElement>(null);
  const widget = useRef<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  useEffect(() => {
    const element = container.current;
    if (!siteKey || !element) return;
    let cancelled = false;
    const theme = element.closest("[data-contygo-theme]")?.getAttribute("data-contygo-theme") === "light" ? "light" : "dark";
    const mount = () => {
      if (cancelled || widget.current || !window.turnstile) return;
      widget.current = window.turnstile.render(element, {
        sitekey: siteKey, action: "contratar", theme, size: "flexible", language: "es",
        callback: (value: string) => setToken(value),
        "expired-callback": () => setToken(null),
        "error-callback": () => setToken(null),
      });
    };
    let script = document.querySelector<HTMLScriptElement>("script[data-turnstile]");
    if (!script) {
      script = document.createElement("script");
      script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit";
      script.async = true; script.defer = true; script.dataset.turnstile = "true";
      document.head.appendChild(script);
    }
    if (window.turnstile) mount(); else script.addEventListener("load", mount, { once: true });
    return () => {
      cancelled = true;
      script?.removeEventListener("load", mount);
      if (widget.current && window.turnstile) window.turnstile.remove(widget.current);
      widget.current = null;
    };
  }, [siteKey]);
  const reset = useCallback(() => { setToken(null); if (widget.current && window.turnstile) window.turnstile.reset(widget.current); }, []);
  // Sin clave de sitio (desarrollo), el servidor no exige CAPTCHA.
  return { container, token: siteKey ? token : "dev", reset, required: Boolean(siteKey) };
}

async function postJson(url: string, body: unknown) {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body), cache: "no-store" });
  const data = await response.json().catch(() => null) as ({ ok?: boolean; error?: string; outcome?: ApiOutcome } & Record<string, unknown>) | null;
  return { status: response.status, data };
}

export default function ContractCheckout({ service, displayName = "" }: { service: ContygoService; displayName?: string }) {
  const [data, setData] = useState<ServiceData | null>(null);
  const [stage, setStage] = useState<Stage>("loading");
  const [notice, setNotice] = useState<Notice | null>(null);
  const [errors, setErrors] = useState<FieldErrors>({});
  const [busy, setBusy] = useState(false);
  const [maskedEmail, setMaskedEmail] = useState("");
  const [code, setCode] = useState("");
  const [result, setResult] = useState<Result | null>(null);
  const [pendingRestart, setPendingRestart] = useState(false);
  const [form, setForm] = useState({ firstName: "", middleName: "", lastName: "", email: "", phone: "", line1: "", apartment: "", city: "", state: "", zip: "", locale: "es" as "es" | "en", planId: "", installmentId: "" });
  const [persons, setPersons] = useState<Person[]>([]);
  const [consent, setConsent] = useState<{ accepted: boolean; at: string }>({ accepted: false, at: "" });
  const personKey = useRef(0);
  const root = useRef<HTMLDivElement>(null);
  const codeInput = useRef<HTMLInputElement>(null);
  const uid = useId();
  const captcha = useTurnstile(data?.captchaSiteKey ?? null);

  const load = useCallback(async () => {
    setStage("loading"); setNotice(null);
    try {
      const { status, data: body } = await postJson("/api/contratar/servicio", { serviceId: service.id });
      if (status !== 200 || !body?.ok) throw new Error(body?.error ?? String(status));
      const next = body as unknown as ServiceData;
      setData(next);
      const plan = next.service.plans[0];
      const prefillName = (next.session.prefill?.fullName || displayName).trim();
      setForm(current => ({ ...current, planId: current.planId || plan?.id || "", firstName: current.firstName || prefillName.split(" ")[0] || "", phone: current.phone || displayPhone(next.session.prefill?.phone ?? "") }));
      setPersons(current => current.length ? current : next.service.partyRoles.filter(role => role.isRequired).map(role => ({ key: ++personKey.current, role: role.roleKey, firstName: "", middleName: "", lastName: "", dateOfBirth: "" })));
      if (next.session.caseNumber) { setResult({ clientCreated: false, caseNumber: next.session.caseNumber, signingUrl: null, serviceAlreadyLive: null, firstName: "" }); setStage("done"); setNotice({ tone: "info", ...outcomeMessage({ step: "ALREADY_DONE", caseNumber: next.session.caseNumber }) }); }
      else if (next.session.eligible === false) { setStage("blocked"); setNotice({ tone: "info", ...outcomeMessage({ step: "NOT_ELIGIBLE" }) }); }
      else if (!next.session.answered) { setStage("blocked"); setNotice({ tone: "info", ...outcomeMessage({ step: "NEEDS_ANSWERS" }) }); }
      else setStage("form");
    } catch {
      setStage("failed");
      setNotice({ tone: "error", title: "No pudimos cargar los datos de tu servicio.", detail: "Revisa tu conexión e inténtalo de nuevo." });
    }
  }, [service.id, displayName]);
  useEffect(() => { void load(); }, [load]);

  const roles = data?.service.partyRoles ?? [];
  const plan = data?.service.plans.find(item => item.id === form.planId) ?? data?.service.plans[0];
  const input = useMemo(() => ({
    firstName: form.firstName, middleName: form.middleName, lastName: form.lastName, email: form.email, phone: form.phone,
    address: { line1: form.line1, apartment: form.apartment, city: form.city, state: form.state, zip: form.zip },
    locale: form.locale, servicePlanId: form.planId, ...(form.installmentId ? { installmentOptionId: form.installmentId } : {}),
    parties: persons.map(({ role, firstName, middleName, lastName, dateOfBirth }) => ({ role, firstName, ...(middleName.trim() ? { middleName } : {}), lastName, ...(dateOfBirth ? { dateOfBirth } : {}) })),
    consent,
  }), [form, persons, consent]);

  function show(outcome: ApiOutcome) {
    const roleLabel = outcome.step === "INVALID_PARTIES" ? text(roles.find(role => role.roleKey === outcome.role)?.label) : undefined;
    const message = outcomeMessage(outcome, roleLabel);
    const tone: Notice["tone"] = ["WRONG_CODE", "ERROR", "INVALID", "INVALID_PARTIES", "RETRY_LATER", "UNAVAILABLE"].includes(outcome.step) ? "error" : "info";
    setNotice({ tone, ...message });
  }

  function handle(status: number, body: Awaited<ReturnType<typeof postJson>>["data"]) {
    if (status === 429) { show({ step: "RETRY_LATER", reason: "destination" }); return; }
    if (status === 403 && body?.error?.startsWith("captcha")) { setNotice({ tone: "error", title: "No pudimos confirmar que no eres un robot.", detail: "Espera a que se complete la verificación e inténtalo de nuevo." }); return; }
    if (status === 409 && body?.error === "no_session") { setStage("blocked"); show({ step: "NEEDS_ANSWERS" }); return; }
    const outcome = body?.outcome;
    if (status !== 200 || !outcome) { setStage("blocked"); show({ step: "ERROR" }); return; }
    switch (outcome.step) {
      case "INVALID":
        setErrors(outcome.errors ?? {});
        if (outcome.errors?.code) setNotice({ tone: "error", title: outcome.errors.code });
        else { setStage("form"); show(outcome); }
        return;
      case "ASK_CODE":
        setMaskedEmail(outcome.maskedEmail ?? ""); setCode(""); setStage("code"); show(outcome);
        window.requestAnimationFrame(() => codeInput.current?.focus({ preventScroll: true }));
        return;
      case "SIGN":
        setResult({ clientCreated: outcome.clientCreated, caseNumber: (outcome as { caseNumber?: string }).caseNumber ?? "", signingUrl: outcome.signingUrl ?? null, serviceAlreadyLive: outcome.serviceAlreadyLive, firstName: outcome.firstName });
        setStage("done"); setNotice({ tone: "success", ...outcomeMessage(outcome) });
        return;
      case "ALREADY_DONE":
        setResult(current => current ?? { clientCreated: false, caseNumber: outcome.caseNumber ?? "", signingUrl: null, serviceAlreadyLive: null, firstName: "" });
        setStage("done"); show(outcome);
        return;
      case "WRONG_CODE": setCode(""); show(outcome); return;
      case "RESTART": show(outcome); setStage("code"); setPendingRestart(true); return;
      case "INVALID_PARTIES": setStage("form"); show(outcome); return;
      case "RETRY_LATER": show(outcome); return;
      default: setStage("blocked"); show(outcome); // HUMAN, NOT_ELIGIBLE, UNAVAILABLE, NEEDS_ANSWERS, ERROR
    }
  }

  async function start() {
    if (!data || busy) return;
    const check = validateContractForm(input, data.service);
    if (!check.ok) {
      setErrors(check.errors); show({ step: "INVALID" });
      window.requestAnimationFrame(() => root.current?.querySelector<HTMLElement>("[data-invalid=true] input, [data-invalid=true] select")?.focus());
      return;
    }
    if (!captcha.token) { setNotice({ tone: "info", title: "Un momento: estamos confirmando que no eres un robot.", detail: "Cuando termine la verificación, pulsa «Contratar» otra vez." }); return; }
    setErrors({}); setBusy(true);
    try {
      const { status, data: body } = await postJson("/api/contratar/iniciar", { form: input, captchaToken: captcha.token });
      handle(status, body);
    } catch { show({ step: "RETRY_LATER", reason: "busy" }); }
    finally { captcha.reset(); setBusy(false); }
  }

  // Código caducado: se pide uno nuevo en cuanto hay un token de CAPTCHA fresco.
  const startRef = useRef(start); startRef.current = start;
  useEffect(() => {
    if (!pendingRestart || !captcha.token || busy) return;
    setPendingRestart(false);
    void startRef.current();
  }, [pendingRestart, captcha.token, busy]);

  async function confirm() {
    if (busy) return;
    const clean = code.replace(/\D/g, "");
    if (clean.length !== 6) { setNotice({ tone: "error", title: "El código tiene 6 dígitos." }); return; }
    setBusy(true);
    try {
      const { status, data: body } = await postJson("/api/contratar/confirmar", { code: clean });
      handle(status, body);
    } catch { show({ step: "RETRY_LATER", reason: "busy" }); }
    finally { setBusy(false); }
  }

  async function resend() {
    if (busy) return;
    setBusy(true);
    try {
      const { status, data: body } = await postJson("/api/contratar/reenviar", {});
      const outcome = body?.outcome as { step: string; signingUrl?: string } | undefined;
      if (status === 200 && outcome?.step === "SIGN_LINK" && outcome.signingUrl) {
        setResult(current => current ? { ...current, signingUrl: outcome.signingUrl! } : current);
        setNotice({ tone: "success", title: "Listo: te lo enviamos también a tu correo y a tu app de ContyGo." });
      } else if (outcome?.step === "ALREADY_SIGNED") setNotice({ tone: "success", title: "Tu contrato ya está firmado." });
      else if (status === 429 || outcome?.step === "RETRY_LATER") show({ step: "RETRY_LATER", reason: "destination" });
      else show({ step: "ERROR" });
    } catch { show({ step: "RETRY_LATER", reason: "busy" }); }
    finally { setBusy(false); }
  }

  // Cada campo de la ficha y la clave con la que el validador nombra su error.
  const errorKey: Partial<Record<keyof typeof form, string>> = { line1: "address.line1", apartment: "address.apartment", city: "address.city", state: "address.state", zip: "address.zip" };
  const set = (key: keyof typeof form) => (event: { target: { value: string } }) => {
    const value = event.target.value;
    setForm(current => ({ ...current, [key]: value }));
    setErrors(current => { const next = { ...current }; delete next[errorKey[key] ?? key]; return next; });
  };
  const setPerson = (key: number, patch: Partial<Person>) => setPersons(current => current.map(person => person.key === key ? { ...person, ...patch } : person));
  const field = (name: string, label: string, control: ReactNode, hint?: string) => <label className={s.field} data-invalid={Boolean(errors[name])}>
    <span>{label}</span>{control}{errors[name] ? <small className={s.error} role="alert">{errors[name]}</small> : hint ? <small>{hint}</small> : null}
  </label>;
  const whatsapp = WHATSAPP + encodeURIComponent(`Hola, quiero ayuda para contratar ${service.name} en ContyGo.`);

  return <div ref={root} className={s.checkout} data-stage={stage} aria-busy={busy || stage === "loading"}>
    <div className={s.card}>
      <header className={s.head}>
        <span className={s.nucleus} aria-hidden="true"><img src="/contygo/brand/symbol-light.png" alt="" /></span>
        <span className={s.eyebrow}>{service.name} · Tu contrato</span>
        <h3 className={s.title}>{stage === "done" ? "Tu siguiente paso: firmar." : stage === "code" ? "Confirma que eres tú." : "Preparemos tu contrato."}</h3>
        {stage === "form" && <p className={s.lead}>Con estos datos preparamos tu contrato en ContyGo. Escribe tu nombre como aparece en tus documentos.</p>}
      </header>

      {notice && <div className={s.notice} data-tone={notice.tone} role={notice.tone === "error" ? "alert" : "status"}><strong>{notice.title}</strong>{notice.detail && <span>{notice.detail}</span>}</div>}

      {stage === "loading" && <div className={s.loading} role="status"><i /><i /><i /><span>Preparando tu ficha…</span></div>}
      {stage === "failed" && <button type="button" className={s.secondary} onClick={() => void load()}>Reintentar</button>}

      {stage === "form" && data && <form className={s.form} noValidate onSubmit={event => { event.preventDefault(); void start(); }}>
        <section className={s.section} aria-labelledby={`${uid}-you`}>
          <h4 id={`${uid}-you`}>Tus datos</h4>
          <div className={s.grid3}>
            {field("firstName", "Nombre", <input autoComplete="given-name" maxLength={80} value={form.firstName} onChange={set("firstName")} />)}
            {field("middleName", "Segundo nombre", <input autoComplete="additional-name" maxLength={80} value={form.middleName} onChange={set("middleName")} />, "Opcional")}
            {field("lastName", "Apellidos", <input autoComplete="family-name" maxLength={120} value={form.lastName} onChange={set("lastName")} />)}
          </div>
          <div className={s.grid2}>
            {field("email", "Correo electrónico", <input type="email" inputMode="email" autoComplete="email" maxLength={160} value={form.email} onChange={set("email")} />, "Ahí te llegará el código para confirmar.")}
            {field("phone", "Teléfono", <input type="tel" inputMode="tel" autoComplete="tel" maxLength={25} value={form.phone} onChange={set("phone")} placeholder="(305) 555-0199" />, "Si no es de EE. UU., empieza con + y el código de país.")}
          </div>
        </section>

        <section className={s.section} aria-labelledby={`${uid}-home`}>
          <h4 id={`${uid}-home`}>Tu dirección</h4>
          <div className={s.grid2}>
            {field("address.line1", "Dirección", <input autoComplete="address-line1" maxLength={200} value={form.line1} onChange={set("line1")} />)}
            {field("address.apartment", "Apartamento", <input autoComplete="address-line2" maxLength={200} value={form.apartment} onChange={set("apartment")} />, "Opcional")}
          </div>
          <div className={s.grid3}>
            {field("address.city", "Ciudad", <input autoComplete="address-level2" maxLength={120} value={form.city} onChange={set("city")} />)}
            {field("address.state", "Estado", <select autoComplete="address-level1" value={form.state} onChange={set("state")}>
              <option value="">Elige…</option>
              {US_STATES.map(state => <option key={state.code} value={state.code}>{state.name}</option>)}
              <option value="PR">Puerto Rico</option>
            </select>)}
            {field("address.zip", "Código postal", <input inputMode="numeric" autoComplete="postal-code" maxLength={10} value={form.zip} onChange={set("zip")} />)}
          </div>
        </section>

        <section className={s.section} aria-labelledby={`${uid}-plan`}>
          <h4 id={`${uid}-plan`}>{data.service.plans.length > 1 ? "Elige tu paquete" : "Tu paquete"}</h4>
          <div className={s.options} role="radiogroup" aria-labelledby={`${uid}-plan`}>
            {data.service.plans.map(item => <label key={item.id} className={s.option} data-selected={form.planId === item.id}>
              <input type="radio" name={`${uid}-plan`} checked={form.planId === item.id} onChange={() => setForm(current => ({ ...current, planId: item.id, installmentId: "" }))} />
              <span>{text(item.name)}{item.extraPartyPriceCents > 0 && <small>+ {cents(item.extraPartyPriceCents)} por persona adicional</small>}</span>
              <strong>{cents(item.priceCents)}</strong>
            </label>)}
          </div>
          {errors.servicePlanId && <small className={s.error} role="alert">{errors.servicePlanId}</small>}
          {plan && plan.installmentOptions.length > 0 ? <div className={s.options} role="radiogroup" aria-label="Opción de pago">
            <label className={s.option} data-selected={!form.installmentId}><input type="radio" name={`${uid}-pay`} checked={!form.installmentId} onChange={() => setForm(current => ({ ...current, installmentId: "" }))} /><span>Plan de pagos del paquete</span></label>
            {plan.installmentOptions.map(option => <label key={option.id} className={s.option} data-selected={form.installmentId === option.id}>
              <input type="radio" name={`${uid}-pay`} checked={form.installmentId === option.id} onChange={() => setForm(current => ({ ...current, installmentId: option.id }))} />
              <span>{option.installmentCount} {option.installmentCount === 1 ? "pago" : option.frequency === "weekly" ? "pagos semanales" : "pagos mensuales"}{option.downpaymentCents !== null && <small>Anticipo de {cents(option.downpaymentCents)}</small>}</span>
            </label>)}
          </div> : <p className={s.note}>El plan de pagos aparece en tu contrato antes de firmar.</p>}
          <p className={s.note}>Honorarios del servicio. Las tasas del gobierno, cuando aplican, van aparte y se indican en tu contrato.</p>
        </section>

        {roles.length > 0 && <section className={s.section} aria-labelledby={`${uid}-people`}>
          <h4 id={`${uid}-people`}>Personas en tu expediente</h4>
          {roles.map(role => {
            const list = persons.filter(person => person.role === role.roleKey);
            const label = text(role.label);
            return <div key={role.roleKey} className={s.role}>
              <p className={s.roleTitle}>{label}{role.isRequired ? <em>Obligatorio</em> : <em data-optional>Opcional</em>}</p>
              {errors[`role.${role.roleKey}`] && <small className={s.error} role="alert">{errors[`role.${role.roleKey}`]}</small>}
              {list.map(person => {
                const index = persons.indexOf(person);
                return <fieldset key={person.key} className={s.person}>
                  <legend>{label} {list.length > 1 ? list.indexOf(person) + 1 : ""}</legend>
                  <div className={s.grid3}>
                    {field(`parties.${index}.firstName`, "Nombre", <input maxLength={80} value={person.firstName} onChange={event => setPerson(person.key, { firstName: event.target.value })} />)}
                    {field(`parties.${index}.middleName`, "Segundo nombre", <input maxLength={80} value={person.middleName} onChange={event => setPerson(person.key, { middleName: event.target.value })} />, "Opcional")}
                    {field(`parties.${index}.lastName`, "Apellidos", <input maxLength={120} value={person.lastName} onChange={event => setPerson(person.key, { lastName: event.target.value })} />)}
                  </div>
                  <div className={s.personFooter}>
                    {field(`parties.${index}.dateOfBirth`, "Fecha de nacimiento", <input type="date" min="1900-01-01" max={new Date().toISOString().slice(0, 10)} value={person.dateOfBirth} onChange={event => setPerson(person.key, { dateOfBirth: event.target.value })} />, "Opcional")}
                    {!(role.isRequired && list.length === 1) && <button type="button" className={s.linkButton} onClick={() => setPersons(current => current.filter(item => item.key !== person.key))}>Quitar</button>}
                  </div>
                </fieldset>;
              })}
              {(role.cardinality !== "single" || list.length === 0) && <button type="button" className={s.add} onClick={() => setPersons(current => [...current, { key: ++personKey.current, role: role.roleKey, firstName: "", middleName: "", lastName: "", dateOfBirth: "" }])}>+ Añadir {label.toLowerCase()}</button>}
            </div>;
          })}
        </section>}

        <section className={s.section} aria-labelledby={`${uid}-lang`}>
          <h4 id={`${uid}-lang`}>Idioma de tus correos y del contrato</h4>
          <div className={s.segmented} role="radiogroup" aria-labelledby={`${uid}-lang`}>
            {(["es", "en"] as const).map(locale => <label key={locale} data-selected={form.locale === locale}><input type="radio" name={`${uid}-lang`} checked={form.locale === locale} onChange={() => setForm(current => ({ ...current, locale }))} />{locale === "es" ? "Español" : "English"}</label>)}
          </div>
        </section>

        <label className={s.consent} data-invalid={Boolean(errors.consent)}>
          <input type="checkbox" checked={consent.accepted} onChange={event => { setConsent(event.target.checked ? { accepted: true, at: new Date().toISOString() } : { accepted: false, at: "" }); setErrors(current => { const next = { ...current }; delete next.consent; return next; }); }} />
          <span>{data.terms.es} <a href="/terminos" target="_blank" rel="noopener noreferrer">Términos</a> · <a href="/privacidad" target="_blank" rel="noopener noreferrer">Privacidad</a></span>
        </label>
        {errors.consent && <small className={s.error} role="alert">{errors.consent}</small>}
      </form>}

      {stage === "code" && <form className={s.codeForm} onSubmit={event => { event.preventDefault(); void confirm(); }}>
        <label className={s.codeField}>
          <span>Código de 6 dígitos</span>
          <input ref={codeInput} value={code} onChange={event => setCode(event.target.value.replace(/\D/g, "").slice(0, 6))} inputMode="numeric" autoComplete="one-time-code" pattern="\d{6}" maxLength={6} aria-describedby={`${uid}-code-help`} disabled={busy || pendingRestart} />
        </label>
        <p id={`${uid}-code-help`} className={s.note}>Lo enviamos a {maskedEmail || "tu correo"}. Si no lo ves, revisa la carpeta de correo no deseado.</p>
        <button type="submit" className={s.primary} disabled={busy || pendingRestart || code.length !== 6}><span>{busy ? "Confirmando…" : "Confirmar"}</span><i aria-hidden="true"><Arrow /></i></button>
        <div className={s.links}>
          <button type="button" className={s.linkButton} disabled={busy} onClick={() => { setStage("form"); setCode(""); setNotice({ tone: "info", title: "Corrige lo que necesites y pulsa «Contratar»: te enviaremos un código nuevo." }); }}>Corregir mis datos</button>
          <button type="button" className={s.linkButton} disabled={busy || pendingRestart} onClick={() => void start()}>¿No te llegó? Enviar otro código</button>
        </div>
      </form>}

      {(stage === "form" || stage === "code") && data && <div className={s.captcha}>
        <div ref={captcha.container} className={s.captchaBox} />
        {stage === "form" && <>
          <button type="button" className={s.primary} disabled={busy} onClick={() => void start()}><span>{busy ? "Enviando…" : "Contratar"}</span><i aria-hidden="true"><Arrow /></i></button>
          <p className={s.note}>Primero te enviamos un código a tu correo para confirmar que eres tú. Firmas en ContyGo cuando estés listo.</p>
        </>}
      </div>}

      {stage === "done" && result && <div className={s.done}>
        {result.serviceAlreadyLive && <p className={s.warning}>{serviceAlreadyLiveMessage(result.serviceAlreadyLive)}</p>}
        {result.signingUrl
          ? <a className={s.primary} href={result.signingUrl} target="_blank" rel="noopener noreferrer"><span>Firmar mi contrato</span><i aria-hidden="true"><Arrow /></i></a>
          : <button type="button" className={s.primary} disabled={busy} onClick={() => void resend()}><span>{busy ? "Enviando…" : "Enviarme el enlace para firmar"}</span><i aria-hidden="true"><Arrow /></i></button>}
        {result.caseNumber && <p className={s.caseNumber}>Tu número de caso: <strong>{result.caseNumber}</strong></p>}
        {result.clientCreated && <p className={s.note}>Entra a tu app de ContyGo con tu correo. Tu contraseña inicial son los 10 dígitos de tu teléfono.</p>}
        <p className={s.note}>El enlace para firmar vale 14 días y también te llega por correo. <a href="/contratar/gracias">Ver el estado de mi contrato</a></p>
        {result.signingUrl && <button type="button" className={s.linkButton} disabled={busy} onClick={() => void resend()}>¿No te llegó el enlace? Reenviarlo</button>}
      </div>}

      {stage === "blocked" && <div className={s.links}>
        <a className={s.secondary} href={whatsapp} target="_blank" rel="noopener noreferrer">Hablar con un asesor</a>
      </div>}
    </div>
  </div>;
}

function Arrow() {
  return <svg viewBox="0 0 24 24" fill="none"><path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}
