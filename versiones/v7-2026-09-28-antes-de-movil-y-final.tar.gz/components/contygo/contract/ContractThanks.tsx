"use client";

/* Página de «gracias»: en qué punto está el contrato de ESTE navegador (cookie de la
   sesión) y, si hace falta, el reenvío del enlace de firma. Sin datos personales. */
import { useCallback, useEffect, useState } from "react";
import s from "./ContractCheckout.module.css";

type Status = { caseNumber: string; clientCreated: boolean; contract: "draft" | "sent" | "signed" | "cancelled"; signingExpiresAt: string | null; downpayment: "none" | "pending" | "paid" | "waived"; checkedAt: string | null };
const dateFormat = new Intl.DateTimeFormat("es-US", { day: "numeric", month: "long" });

async function post(url: string) {
  const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}", cache: "no-store" });
  return { status: response.status, body: await response.json().catch(() => null) as Record<string, unknown> | null };
}

export default function ContractThanks() {
  const [status, setStatus] = useState<Status | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "missing" | "error">("loading");
  const [signingUrl, setSigningUrl] = useState<string | null>(null);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const refresh = useCallback(async () => {
    setBusy(true);
    try {
      const { status: code, body } = await post("/api/contratar/estado");
      if (code === 404) { setState("missing"); return; }
      if (code !== 200 || !body?.ok) { setState(current => current === "ready" ? "ready" : "error"); setMessage("No pudimos consultar el estado ahora. Inténtalo en un minuto."); return; }
      setStatus(body as unknown as Status); setState("ready"); setMessage("");
    } catch { setState("error"); }
    finally { setBusy(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);

  async function resend() {
    setBusy(true);
    try {
      const { status: code, body } = await post("/api/contratar/reenviar");
      const outcome = body?.outcome as { step?: string; signingUrl?: string } | undefined;
      if (code === 200 && outcome?.step === "SIGN_LINK" && outcome.signingUrl) { setSigningUrl(outcome.signingUrl); setMessage("Listo: también te lo enviamos a tu correo y a tu app de ContyGo."); }
      else if (outcome?.step === "ALREADY_SIGNED") { setMessage("Tu contrato ya está firmado."); void refresh(); }
      else if (code === 429 || outcome?.step === "RETRY_LATER") setMessage("Por seguridad, espera unos minutos antes de intentarlo de nuevo.");
      else setMessage("No pudimos reenviar el enlace. Un asesor te contactará.");
    } catch { setMessage("No pudimos reenviar el enlace. Revisa tu conexión."); }
    finally { setBusy(false); }
  }

  const signed = status?.contract === "signed";
  const title = state === "missing" ? "No encontramos un contrato en este navegador."
    : !status ? "Consultando tu contrato…"
    : signed ? status.downpayment === "paid" || status.downpayment === "waived" ? "¡Listo! Tu caso ya arrancó." : "¡Contrato firmado!"
    : status.contract === "cancelled" ? "Este contrato se canceló." : "Tu contrato espera tu firma.";
  const detail = !status ? "" : signed
    ? status.downpayment === "paid" || status.downpayment === "waived" ? "Recibimos tu pago inicial. Sigue tus próximos pasos en tu app de ContyGo." : "El siguiente paso es el pago inicial. Lo verás en tu app de ContyGo."
    : status.contract === "sent" ? `Lo preparamos con tus datos. ${status.signingExpiresAt ? `El enlace para firmar vale hasta el ${dateFormat.format(new Date(status.signingExpiresAt))}.` : ""}` : "";

  return <div className={s.checkout} style={{ minHeight: "100dvh", height: "auto" }}>
    <div className={s.card}>
      <header className={s.head}>
        <span className={s.nucleus} aria-hidden="true"><img src="/contygo/brand/symbol-light.png" alt="" /></span>
        <span className={s.eyebrow}>ContyGo · Tu contrato</span>
        <h1 className={s.title}>{title}</h1>
        {detail && <p className={s.lead}>{detail}</p>}
      </header>
      {status?.caseNumber && <p className={s.caseNumber}>Tu número de caso: <strong>{status.caseNumber}</strong></p>}
      {message && <div className={s.notice} data-tone="info" role="status"><strong>{message}</strong></div>}
      {status?.contract === "sent" && (signingUrl
        ? <a className={s.primary} href={signingUrl} target="_blank" rel="noopener noreferrer"><span>Firmar mi contrato</span><i aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg></i></a>
        : <button type="button" className={s.primary} disabled={busy} onClick={() => void resend()}><span>{busy ? "Enviando…" : "Enviarme el enlace para firmar"}</span><i aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg></i></button>)}
      {status?.clientCreated && <p className={s.note}>Entra a tu app de ContyGo con tu correo. Tu contraseña inicial son los 10 dígitos de tu teléfono.</p>}
      <div className={s.links}>
        {state !== "missing" && <button type="button" className={s.linkButton} disabled={busy} onClick={() => void refresh()}>Actualizar estado</button>}
        <a className={s.linkButton} href="https://contygo.app/entrar">Entrar a mi cuenta</a>
        <a className={s.linkButton} href="/">Volver al inicio</a>
      </div>
    </div>
  </div>;
}
