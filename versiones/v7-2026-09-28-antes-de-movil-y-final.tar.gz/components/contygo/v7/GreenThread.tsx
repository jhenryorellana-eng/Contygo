"use client";

import { useEffect, useRef, type RefObject } from "react";
import s from "./ContygoLanding.module.css";

/**
 * «El hilo verde»: the paper ribbon of the hero leaves its image and becomes a thread
 * that follows the reader down the page, crosses the four journey steps and ends as the
 * long stroke of the ContyGo check. Anchors are read from `[data-thread]` elements.
 */
type Knot = { x: number; y: number; tx: number; ty: number };
type Box = { x: number; y: number; w: number; h: number };

const DOWN = { tx: 0, ty: 1 };
const RIGHT = { tx: 1, ty: 0 };
// symbol-*.png: long stroke from its tip (73.7%, 23.4%) toward the vertex (46.4%, 56.2%).
const CHECK_TIP = { x: .737, y: .234 };
const CHECK = unit(-.64, .77);
// Where the hero ribbon leaves the bottom edge of its image, as a fraction of the width. Each hero
// image declares its own measured point in `data-exit`; this is the fallback of the V6 sculpture.
const RIBBON_EXIT = .23;
const HEAD_LINE = .62;

function unit(tx: number, ty: number) { const l = Math.hypot(tx, ty) || 1; return { tx: tx / l, ty: ty / l }; }

/** Layout position inside `root`, unaffected by the unfold transforms of revealed elements. */
function offset(el: HTMLElement, root: HTMLElement): Box {
  let x = 0, y = 0, node: HTMLElement | null = el;
  while (node && node !== root) { x += node.offsetLeft; y += node.offsetTop; node = node.offsetParent as HTMLElement | null; }
  return { x, y, w: el.offsetWidth, h: el.offsetHeight };
}

/** Area painted by an image aligned to the bottom, with `object-fit: contain` or `cover` (top cropped). */
function painted(img: HTMLImageElement, root: HTMLElement): Box {
  const b = offset(img, root);
  const ratio = img.naturalWidth && img.naturalHeight ? img.naturalWidth / img.naturalHeight : 4 / 3;
  const cover = getComputedStyle(img).objectFit === "cover";
  const w = cover ? Math.max(b.w, b.h * ratio) : Math.min(b.w, b.h * ratio), h = w / ratio;
  return { x: b.x + (b.w - w) / 2, y: b.y + b.h - h, w, h };
}

function route(main: HTMLElement) {
  const q = (name: string) => main.querySelector<HTMLElement>(`[data-thread="${name}"]`);
  const start = q("start"), img = start?.querySelector("img");
  const services = q("services"), platform = q("platform"), faq = q("faq"), finale = q("finale"), facts = q("facts");
  const steps = Array.from(main.querySelectorAll<HTMLElement>('[data-thread="step"]')).map(el => offset(el, main));
  if (!img || !services || !platform || !faq || !finale || !steps.length) return null;
  const width = main.clientWidth, mobile = width <= 760, inner = Math.min(width, 1440);
  const gutter = mobile ? 11 : (width - inner) / 2 + inner * .025;
  const lane = mobile ? gutter : width - gutter;
  const knot = (x: number, y: number, d: { tx: number; ty: number }): Knot => ({ x, y, ...d });
  const art = painted(img, main), mark = offset(finale, main);
  // The first sweep runs along the top edge of the facts strip (never across its numbers), then
  // the thread goes down the margin; without the strip it stays in the gap before the services.
  // Phones show the art above the headline: the thread turns into the margin right at the image's
  // lower edge, before the eyebrow, and runs down beside the text.
  // A ribbon that leaves the image heading down (data-exit-dir="down") keeps falling, then
  // turns along the facts strip on desktop or slides into the margin on phones.
  const exit = { x: art.x + art.w * (Number(start?.dataset.exit) || RIBBON_EXIT), y: art.y + art.h - 1 };
  const falling = start?.dataset.exitDir === "down";
  const knots = falling ? [
    knot(exit.x, exit.y, unit(-.12, 1)),
    ...(mobile ? [knot(gutter, exit.y + 40, DOWN)] : facts ? [knot(exit.x - 60, offset(facts, main).y + 22, unit(-1, 0))] : []),
  ] : [
    knot(exit.x, exit.y - 1, unit(-1, mobile ? .05 : facts ? .08 : .22)),
    ...(mobile ? [knot(gutter, art.y + art.h + 10, DOWN)] : []),
  ];
  knots.push(
    facts ? knot(gutter, offset(facts, main).y + 22, DOWN) : knot(gutter, offset(services, main).y + (mobile ? 44 : 100), DOWN),
    knot(gutter, steps[0].y - (mobile ? 90 : 150), DOWN),
    ...steps.map(step => knot(step.x + 3, step.y, mobile ? DOWN : RIGHT)),
  );
  const last = steps[steps.length - 1];
  if (!mobile) knots.push(knot(last.x + last.w, last.y, RIGHT));
  const faqBox = offset(faq, main);
  knots.push(
    knot(lane, offset(platform, main).y + 60, DOWN),
    knot(lane, faqBox.y + faqBox.h - (mobile ? 140 : 260), DOWN),
    knot(mark.x + mark.w * CHECK_TIP.x, mark.y + mark.h * CHECK_TIP.y, CHECK),
  );
  // On desktop the steps share one line: that stretch is drawn while the section scrolls by.
  return { knots, row: mobile ? null : { y: steps[0].y, x: steps[0].x + 3 } };
}

/* ---- Lo que el hilo activa al pasar (data-react) ----
   Animaciones de Web Animations en modo aditivo: se suman a las entradas CSS (data-reveal)
   sin pisarlas. Con «reducir movimiento» no se ejecuta ninguna. */
const EASE = "cubic-bezier(.2,.8,.2,1)";
const GLOW = "0 0 0 1.5px rgba(37,211,102,.75), 0 18px 46px -12px rgba(37,211,102,.45)";

/** 12 · $50 · +500 · 100%: cuenta desde 0 conservando prefijo y sufijo. */
function countUp(el: HTMLElement) {
  const target = el.dataset.value ?? el.textContent ?? "";
  const match = target.match(/^(\D*)([\d,]+)(\D*)$/);
  if (!match) return;
  const [, prefix, digits, suffix] = match, end = Number(digits.replace(/,/g, ""));
  const start = performance.now(), duration = 1100;
  const step = (now: number) => {
    const t = Math.min(1, (now - start) / duration), value = Math.round(end * (1 - (1 - t) ** 3));
    el.textContent = `${prefix}${value.toLocaleString("en-US")}${suffix}`;
    if (t < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

function react(el: HTMLElement, kind: string, order: number) {
  const delay = order * 90;
  const add = (target: Element | null, frames: Keyframe[], duration: number) =>
    target?.animate(frames, { duration, delay, easing: EASE, composite: "add" });
  switch (kind) {
    case "count": { const n = el.querySelector<HTMLElement>("[data-value]"); if (n) setTimeout(() => countUp(n), delay); break; }
    case "card":
      add(el, [{ transform: "translateY(0)" }, { transform: "translateY(-10px)", offset: .35 }, { transform: "translateY(0)" }], 1100);
      el.animate([{ boxShadow: "0 0 0 0 rgba(37,211,102,0)" }, { boxShadow: GLOW, offset: .3 }, { boxShadow: "0 0 0 0 rgba(37,211,102,0)" }], { duration: 1400, delay, easing: "ease-out", composite: "add" });
      break;
    case "row": add(el.querySelector("img, svg"), [{ transform: "scale(1)" }, { transform: "scale(1.22) rotate(-6deg)", offset: .4 }, { transform: "scale(1)" }], 800); break;
    case "swipe": {
      // A wave runs through the row: each tile rises and glows in turn.
      const items = Array.from(el.children) as HTMLElement[];
      items.forEach((item, index) => {
        const timing = { delay: delay + index * 90, composite: "add" as const };
        item.animate([{ transform: "translateY(0)" }, { transform: "translateY(-8px)", offset: .4 }, { transform: "translateY(0)" }], { ...timing, duration: 900, easing: EASE });
        item.animate([{ boxShadow: "0 0 0 0 rgba(37,211,102,0)" }, { boxShadow: GLOW, offset: .35 }, { boxShadow: "0 0 0 0 rgba(37,211,102,0)" }], { ...timing, duration: 1200, easing: "ease-out" });
      });
      // Phones: the row peeks to show there is more, and a hand invites to swipe (until the person does).
      if (el.scrollWidth - el.clientWidth > 24 && el.scrollLeft < 8) {
        items.forEach(item => item.animate([{ transform: "translateX(0)" }, { transform: "translateX(-78px)", offset: .45 }, { transform: "translateX(0)" }], { duration: 1500, delay: delay + 450, easing: "cubic-bezier(.65,0,.35,1)", composite: "add" }));
        el.dataset.hint = "true";
        const clear = () => { delete el.dataset.hint; el.removeEventListener("scroll", clear); };
        el.addEventListener("scroll", clear, { passive: true });
        setTimeout(clear, 4500);
      }
      break;
    }
    // "scene", "phone" and "title" are pure CSS: a resting state before the thread, a transition after.
    case "pop": add(el.querySelector("svg"), [{ transform: "scale(1)" }, { transform: "scale(1.35)", offset: .4 }, { transform: "scale(1)" }], 700); break;
    case "sheet": el.animate([{ boxShadow: "0 0 0 0 rgba(37,211,102,0)" }, { boxShadow: "0 0 0 2px rgba(37,211,102,.8), 0 0 90px rgba(37,211,102,.35)", offset: .3 }, { boxShadow: "0 0 0 0 rgba(37,211,102,0)" }], { duration: 1800, easing: "ease-out", composite: "add" }); break;
  }
}

function toPath(knots: Knot[]) {
  const f = (n: number) => n.toFixed(1);
  let d = `M${f(knots[0].x)} ${f(knots[0].y)}`;
  for (let i = 1; i < knots.length; i++) {
    const a = knots[i - 1], b = knots[i], dx = b.x - a.x, dy = b.y - a.y;
    // Each handle only reaches as far as the gap measured along its own direction: tight elbows, no overshoot.
    const ra = Math.min(Math.abs(dx * a.tx + dy * a.ty) * .55, 420), rb = Math.min(Math.abs(dx * b.tx + dy * b.ty) * .55, 420);
    d += ` C${f(a.x + a.tx * ra)} ${f(a.y + a.ty * ra)} ${f(b.x - b.tx * rb)} ${f(b.y - b.ty * rb)} ${f(b.x)} ${f(b.y)}`;
  }
  return d;
}

export default function GreenThread({ scope }: { scope: RefObject<HTMLElement> }) {
  const svg = useRef<SVGSVGElement>(null);
  const track = useRef<SVGPathElement>(null);
  const line = useRef<SVGPathElement>(null);
  const trail = useRef<SVGPathElement>(null);
  const head = useRef<SVGGElement>(null);

  useEffect(() => {
    const main = scope.current, svgEl = svg.current, trackEl = track.current, lineEl = line.current, trailEl = trail.current, headEl = head.current;
    if (!main || !svgEl || !trackEl || !lineEl || !trailEl || !headEl) return;
    const still = matchMedia("(prefers-reduced-motion: reduce)");
    let total = 0, drawn = 0, goal = 0, top = 0, frame = 0, pending = 0, arrived = false;
    let lens = new Float32Array(0), xs = new Float32Array(0), ys = new Float32Array(0), reach = new Float32Array(0);
    let row: { y: number; from: number; span: number } | null = null;
    let marks: { el: HTMLElement; at: number }[] = [];
    // Elements that react when the thread passes: `lit` once reached, `--near` while the head goes by.
    let reactors: { el: HTMLElement; kind: string; at: number; order: number; lit: boolean; near: number }[] = [];
    const WAKE = 260;

    const nearest = (x: number, y: number) => {
      let best = 0, bestDistance = Infinity, px = 0;
      for (let i = 0; i < lens.length; i++) { const d = (xs[i] - x) ** 2 + (ys[i] - y) ** 2; if (d < bestDistance) { bestDistance = d; best = lens[i]; px = xs[i]; } }
      return { len: best, distance: bestDistance, x: px };
    };
    const lengthNear = (x: number, y: number) => nearest(x, y).len;
    // `reach` is the running maximum of y, so this search is monotonic in scroll.
    const lengthAt = (y: number) => {
      let lo = 0, hi = reach.length - 1;
      if (hi < 0 || y <= reach[0]) return 0;
      if (y >= reach[hi]) return total;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (reach[mid] < y) lo = mid + 1; else hi = mid; }
      return lens[lo];
    };
    const lengthFor = (y: number) => {
      if (!row || y < row.y || y >= row.y + row.span) return lengthAt(y);
      return row.from + (lengthAt(row.y + row.span) - row.from) * (y - row.y) / row.span;
    };

    function paint() {
      lineEl!.style.strokeDashoffset = String(total - drawn);
      const point = lineEl!.getPointAtLength(Math.max(0, Math.min(drawn, total)));
      headEl!.setAttribute("transform", `translate(${point.x.toFixed(1)} ${point.y.toFixed(1)})`);
      // Comet trail: only the last stretch behind the head glows.
      trailEl!.style.strokeDashoffset = String(-Math.max(0, drawn - 150));
      for (const mark of marks) mark.el.setAttribute("data-reached", String(drawn >= mark.at - 2));
      for (const r of reactors) {
        const lit = drawn >= r.at - 4;
        if (lit !== r.lit) {
          r.lit = lit;
          r.el.dataset.lit = String(lit);
          if (lit && !still.matches) react(r.el, r.kind, r.order);
        }
        const near = still.matches ? 0 : Math.max(0, 1 - Math.abs(drawn - r.at) / WAKE);
        if (Math.abs(near - r.near) > .015) { r.near = near; r.el.style.setProperty("--near", near.toFixed(3)); }
      }
      if (!arrived && total > 0 && drawn >= total - 3) {
        arrived = true;
        main!.querySelector('[data-thread="finale"]')?.setAttribute("data-arrived", "true");
      }
      svgEl!.dataset.arrived = String(arrived && drawn >= total - 3);
    }
    function aim() {
      goal = still.matches ? total : Math.max(0, Math.min(total, lengthFor(scrollY + innerHeight * HEAD_LINE - top)));
    }
    // First visit: the hero image lands first (entrance of about 0.7 s), then its ribbon lets go of the thread.
    const waitUntil = document.documentElement.dataset.cgIntro === "play" && !still.matches ? performance.now() + 700 : 0;
    function tick() {
      frame = 0;
      if (performance.now() < waitUntil) { frame = requestAnimationFrame(tick); return; }
      const diff = goal - drawn;
      // Anchor jumps and restored scroll positions land close to the goal instead of replaying the page.
      drawn = Math.abs(diff) < .5 ? goal : Math.abs(diff) > 1200 ? goal - Math.sign(diff) * 240 : drawn + diff * .16;
      paint();
      if (drawn !== goal) frame = requestAnimationFrame(tick);
    }
    function layout() {
      pending = 0;
      const built = route(main!);
      if (!built) return;
      // offsetHeight, not scrollHeight: the SVG itself must not keep the page from shrinking.
      const height = main!.offsetHeight;
      svgEl!.setAttribute("viewBox", `0 0 ${main!.clientWidth} ${height}`);
      svgEl!.style.height = `${height}px`;
      const d = toPath(built.knots);
      trackEl!.setAttribute("d", d);
      lineEl!.setAttribute("d", d);
      total = lineEl!.getTotalLength();
      lineEl!.style.strokeDasharray = `${total} ${total}`;
      trailEl!.setAttribute("d", d);
      trailEl!.style.strokeDasharray = `150 ${total + 150}`;
      const n = Math.max(2, Math.ceil(total / 6));
      lens = new Float32Array(n); xs = new Float32Array(n); ys = new Float32Array(n); reach = new Float32Array(n);
      let highest = -Infinity;
      for (let i = 0; i < n; i++) {
        const l = total * i / (n - 1), p = lineEl!.getPointAtLength(l);
        lens[i] = l; xs[i] = p.x; ys[i] = p.y; highest = Math.max(highest, p.y); reach[i] = highest;
      }
      row = built.row ? { y: built.row.y, from: lengthNear(built.row.x, built.row.y), span: innerHeight * .45 } : null;
      marks = Array.from(main!.querySelectorAll<HTMLElement>('[data-thread="step"]')).map(el => {
        const b = offset(el, main!);
        return { el, at: lengthNear(b.x + 3, b.y) };
      });
      // Each reactor keys on the stretch of thread closest to it (left, right or top edge), and is
      // pushed away from the thread while the head passes (--side). Siblings of one kind stagger.
      const counters = new Map<Element | null, number>();
      reactors = Array.from(main!.querySelectorAll<HTMLElement>("[data-react]")).map(el => {
        const b = offset(el, main!);
        // data-react-y moves the side anchors up (e.g. .2: react when the top fifth meets the thread).
        const ay = b.y + b.h * (Number(el.dataset.reactY) || .5);
        const hit = [nearest(b.x, ay), nearest(b.x + b.w, ay), nearest(b.x + b.w / 2, b.y)].sort((p, q) => p.distance - q.distance)[0];
        const kind = el.dataset.react ?? "card";
        const order = counters.get(el.parentElement) ?? 0; counters.set(el.parentElement, order + 1);
        el.style.setProperty("--side", String(b.x + b.w / 2 >= hit.x ? 1 : -1));
        const previous = reactors.find(r => r.el === el);
        return { el, kind, at: hit.len, order: Math.min(order, 4), lit: previous?.lit ?? false, near: previous?.near ?? 0 };
      });
      // Counters start at zero until the thread reaches them (never without JavaScript).
      for (const r of reactors) if (r.kind === "count" && !r.lit && !still.matches) {
        const n = r.el.querySelector<HTMLElement>("[data-value]");
        if (n) n.textContent = (n.dataset.value ?? "").replace(/[\d,]+/, "0");
      }
      top = main!.getBoundingClientRect().top + scrollY;
      main!.dataset.threadReady = "true";
      aim();
      drawn = still.matches ? total : Math.min(drawn, total);
      paint();
      if (!frame) frame = requestAnimationFrame(tick);
    }
    const schedule = () => { if (!pending) pending = requestAnimationFrame(layout); };
    const onScroll = () => { aim(); if (!frame) frame = requestAnimationFrame(tick); };

    const observer = new ResizeObserver(schedule);
    observer.observe(main);
    addEventListener("scroll", onScroll, { passive: true });
    addEventListener("resize", schedule);
    still.addEventListener("change", schedule);
    schedule();
    return () => {
      observer.disconnect();
      removeEventListener("scroll", onScroll);
      removeEventListener("resize", schedule);
      still.removeEventListener("change", schedule);
      cancelAnimationFrame(frame); cancelAnimationFrame(pending);
    };
  }, [scope]);

  return <svg ref={svg} className={s.thread} aria-hidden="true" focusable="false" preserveAspectRatio="none">
    <path ref={track} className={s.threadTrack} />
    <path ref={line} className={s.threadLine} />
    <path ref={trail} className={s.threadTrail} />
    <g ref={head} className={s.threadHead}><circle r="30" /><circle r="14" /><circle r="6.5" /></g>
  </svg>;
}
