/* ============================================================
   ContyGo · cambio de tono con una gota
   Al pulsar el botón se forma una gota con los colores del tema
   al que se cambia, cae con gravedad hasta el borde inferior, se
   aplasta, salpica y, desde el punto de impacto, se expande el
   nuevo tono en círculo (View Transitions; si no existen, una
   inundación de color). «Reducir movimiento»: cambio directo.
   ============================================================ */

type Theme = "light" | "dark";
type ViewTransition = { ready: Promise<void>; finished: Promise<void> };
type DocumentWithTransitions = Document & { startViewTransition?: (update: () => void) => ViewTransition };

const LOOK: Record<Theme, { body: [string, string]; rim: string; shine: string; flood: string }> = {
  dark: { body: ["#1d4a86", "#061b3d"], rim: "#25d366", shine: "rgba(255,255,255,.75)", flood: "#061b3d" },
  light: { body: ["#ffffff", "#dfe9e4"], rim: "#087f46", shine: "rgba(255,255,255,1)", flood: "#ffffff" },
};

function dropSvg(theme: Theme) {
  const look = LOOK[theme], id = `cg-drop-${theme}`;
  return `<svg viewBox="0 0 40 52" width="100%" height="100%" aria-hidden="true">
    <defs><radialGradient id="${id}" cx="38%" cy="62%" r="70%"><stop offset="0" stop-color="${look.body[0]}"/><stop offset="1" stop-color="${look.body[1]}"/></radialGradient></defs>
    <path d="M20 1C20 1 37 22 37 34A17 17 0 0 1 3 34C3 22 20 1 20 1Z" fill="url(#${id})" stroke="${look.rim}" stroke-width="1.6" stroke-opacity=".8"/>
    <ellipse cx="13.5" cy="33" rx="3.2" ry="6" fill="${look.shine}" transform="rotate(18 13.5 33)" opacity=".85"/>
    <circle cx="15" cy="43.5" r="1.6" fill="${look.shine}" opacity=".55"/>
  </svg>`;
}

function layer(style: Partial<CSSStyleDeclaration>) {
  const el = document.createElement("div");
  Object.assign(el.style, { position: "fixed", pointerEvents: "none", zIndex: "2147483000", ...style });
  document.body.appendChild(el);
  return el;
}

let busy = false;

/** Deja caer la gota desde `button` y aplica `next` al tocar el borde inferior. */
export async function dropTheme(button: HTMLElement, next: Theme, apply: () => void) {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  if (reduce || typeof document.body.animate !== "function") { apply(); return; }
  if (busy) return;
  busy = true;
  const look = LOOK[next];
  const box = button.getBoundingClientRect();
  const width = 30, height = 39;
  const x = box.left + box.width / 2, start = box.bottom - 6;
  const floor = window.innerHeight - 4;
  const fall = Math.max(120, floor - start - height);
  // Gravedad «de pantalla»: unos 0,55 s para caer 700 px, más rápido si la caída es corta.
  const fallTime = Math.round(Math.min(720, Math.max(340, Math.sqrt((2 * fall) / 4600) * 1000)));

  const drop = layer({ left: `${x - width / 2}px`, top: `${start}px`, width: `${width}px`, height: `${height}px`, transformOrigin: "50% 0%" });
  drop.innerHTML = dropSvg(next);
  try {
    // 1 · Se forma colgando del botón y se estira antes de soltarse.
    await drop.animate([
      { transform: "scale(.15, .1)", opacity: 0 },
      { transform: "scale(.7, .9)", opacity: 1, offset: .45 },
      { transform: "scale(.82, 1.28)", offset: .8 },
      { transform: "scale(.9, 1.12)" },
    ], { duration: 360, easing: "cubic-bezier(.3,.7,.4,1)", fill: "forwards" }).finished;

    // 2 · Cae con aceleración constante: se estira con la velocidad.
    drop.style.transformOrigin = "50% 100%";
    await drop.animate([
      { transform: "translateY(0) scale(.9, 1.12)" },
      { transform: `translateY(${fall * .25}px) scale(.88, 1.2)`, offset: .5 },
      { transform: `translateY(${fall}px) scale(.8, 1.34)` },
    ], { duration: fallTime, easing: "cubic-bezier(.55,.085,.68,.53)", fill: "forwards" }).finished;

    // 3 · Toca el piso: se aplasta y salpica.
    const impactX = x, impactY = floor;
    drop.animate([
      { transform: `translateY(${fall}px) scale(.8, 1.34)` },
      { transform: `translateY(${fall + height * .45}px) scale(1.9, .38)`, offset: .45 },
      { transform: `translateY(${fall + height * .6}px) scale(2.4, .12)`, opacity: 0 },
    ], { duration: 240, easing: "ease-out", fill: "forwards" });
    splash(impactX, impactY, next);
    await reveal(impactX, impactY, look.flood, apply);
  } finally {
    drop.remove();
    busy = false;
  }
}

function splash(x: number, y: number, theme: Theme) {
  const look = LOOK[theme];
  const ring = layer({ left: `${x - 30}px`, top: `${y - 30}px`, width: "60px", height: "60px", borderRadius: "50%", border: `2px solid ${look.rim}` });
  ring.animate([{ transform: "scale(.2, .08)", opacity: .9 }, { transform: "scale(2.6, .7)", opacity: 0 }], { duration: 620, easing: "cubic-bezier(.2,.8,.2,1)" }).finished.then(() => ring.remove());
  const angles = [-160, -128, -100, -80, -52, -20];
  angles.forEach((angle, index) => {
    const size = 5 + (index % 3) * 2;
    const bead = layer({ left: `${x - size / 2}px`, top: `${y - size}px`, width: `${size}px`, height: `${size}px`, borderRadius: "50%", background: look.body[1], boxShadow: `0 0 0 1px ${look.rim}` });
    const rad = (angle * Math.PI) / 180, distance = 34 + (index % 2) * 22;
    const dx = Math.cos(rad) * distance, dy = Math.sin(rad) * distance;
    bead.animate([
      { transform: "translate(0,0) scale(1)", opacity: 1 },
      { transform: `translate(${dx}px, ${dy}px) scale(1)`, opacity: 1, offset: .5 },
      { transform: `translate(${dx * 1.45}px, ${dy * .2 + 10}px) scale(.4)`, opacity: 0 },
    ], { duration: 560, easing: "cubic-bezier(.2,.7,.4,1)" }).finished.then(() => bead.remove());
  });
}

async function reveal(x: number, y: number, flood: string, apply: () => void) {
  const radius = Math.hypot(Math.max(x, window.innerWidth - x), Math.max(y, window.innerHeight - y));
  const from = `circle(0px at ${x}px ${y}px)`, to = `circle(${radius}px at ${x}px ${y}px)`;
  const doc = document as DocumentWithTransitions;
  if (typeof doc.startViewTransition === "function") {
    const root = document.documentElement;
    root.dataset.themeDrop = "on";
    try {
      const transition = doc.startViewTransition(apply);
      await transition.ready;
      root.animate({ clipPath: [from, to] }, { duration: 860, easing: "cubic-bezier(.65,0,.35,1)", pseudoElement: "::view-transition-new(root)" });
      await transition.finished;
    } finally {
      delete root.dataset.themeDrop;
    }
    return;
  }
  // Sin View Transitions: el color del nuevo tono inunda desde el impacto, se cambia debajo y se retira.
  const sheet = layer({ inset: "0", background: flood, clipPath: from });
  await sheet.animate({ clipPath: [from, to] }, { duration: 700, easing: "cubic-bezier(.65,0,.35,1)", fill: "forwards" }).finished;
  apply();
  await sheet.animate({ opacity: [1, 0] }, { duration: 320, easing: "ease-out", fill: "forwards" }).finished;
  sheet.remove();
}
