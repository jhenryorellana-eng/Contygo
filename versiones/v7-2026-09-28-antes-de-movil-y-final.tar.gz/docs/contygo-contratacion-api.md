# ContyGo · Contratación por API desde la landing

Integración del 28 de septiembre de 2026. La persona contrata dentro del recorrido de cada servicio y firma en contygo. Nuestro servidor crea el contrato por API y le muestra el enlace de firma.

**Fuentes:**

- **Guía técnica:** `API-contratacion-contygo.md` (contygo, estado del 25-09-2026).
- **Contrato exacto de cada ruta:** `openapi-motor-de-ventas.yaml`. Si algo no coincide con la guía, **manda el OpenAPI**.
- **Cloudflare Turnstile**, verificado en la web el 28-09-2026:
  - [validación en servidor](https://developers.cloudflare.com/turnstile/get-started/server-side-validation/);
  - [renderizado explícito](https://developers.cloudflare.com/turnstile/get-started/client-side-rendering/);
  - [claves de prueba](https://developers.cloudflare.com/turnstile/troubleshooting/testing/).

## El recorrido

| Momento | Qué pasa | Llamada a contygo |
|---|---|---|
| El chat se abre (tras el vídeo 1) | El bot saluda y hace las preguntas del **catálogo**, no de una lista escrita a mano | `GET /catalog`, que se guarda 5 min |
| La persona responde | Gemini solo interpreta texto o voz de la pregunta actual (sí/no o fecha) | — |
| Última respuesta | contygo evalúa y la sesión del servidor guarda respuestas y veredicto | `POST /eligibility/evaluate`, con `answers[{questionId, value}]` |
| Pantalla del nombre | Nombre y teléfono, los dos opcionales. Si están los dos, se registra el lead | `PUT /leads/web-<sesión>` con `source: "web"`, URL y UTM |
| Botón «Revisar mi contrato» del cierre | Abre la **ficha**: datos, dirección, paquete, personas, idioma, casilla y CAPTCHA | — |
| «Contratar» | CAPTCHA y límites propios. Actualiza el lead y hace la 1.ª llamada: contygo manda el código al correo | `POST /contracts` → `409 CLIENT_VERIFICATION_REQUIRED` |
| Código | El **mismo cuerpo** guardado más `verificationId` y `verificationCode`, con una clave nueva por intento | `POST /contracts` → `201` con `signingUrl` |
| Firma | Botón «Firmar mi contrato». Se abre contygo en el navegador de la persona | — |
| Después | Página `/contratar/gracias`: estado y reenvío del enlace | `GET /contracts/{id}`, que se guarda 60 s · `POST /contracts/{id}/link` |
| Avisos | Webhook firmado: `case.created`, `contract.signed` y `downpayment.confirmed` | contygo → `POST /api/webhooks/contygo` |

Si la respuesta de elegibilidad es negativa, el recorrido continúa: el segundo vídeo sigue disponible. Al llegar a la ficha se explica que el trámite no aplica y se ofrece un asesor. No se contrata.

## Archivos

**Servidor** (`lib/contygo-api/`):

- `client.ts`: una función por endpoint. Reintenta con la misma clave, nunca reintenta un 429 y no escribe en contygo desde desarrollo.
- `catalog.ts`: catálogo en caché, casado con la landing por `slug`.
- `checkout.ts`: validación, cuerpo estricto y traducción de cada respuesta a una pantalla.
- `flow.ts`: el alta en dos pasos.
- `lead.ts`, `store.ts` (sesión del servidor), `server.ts` (cookie firmada, origen, límites y Turnstile) y `webhook.ts` (HMAC).
- `terms.ts`: texto de aceptación versionado.
- `messages.ts`: textos de la sección 5 de la guía.

**Rutas:**

- `app/api/agent/service-intake`: el chat, que ahora pregunta desde el catálogo.
- `app/api/contratar/{servicio,lead,iniciar,confirmar,estado,reenviar}`.
- `app/api/webhooks/contygo`.

**Interfaz:**

- `components/contygo/contract/ContractCheckout.tsx`: la ficha, el código y la firma.
- `ContractThanks.tsx` y `app/contratar/gracias`.
- Cambios en `VisaJuvenilExperience`, que pasa a preguntar desde el catálogo y registra el lead.
- Cambios en `VisaJourneyReveal`, que añade el teléfono y sube los campos a 16 px para que iOS no haga zoom.
- Cambios en `PaperPlaneClosing`, cuyo botón abre la ficha, y en `ServiceCinemaDialog`.

**Base de datos:** `supabase/contygo-contratacion.sql`.

**Pruebas:**

- `tests/contygo-api.test.cjs`, `tests/contygo-contratacion.test.cjs` y `tests/service-intake.test.cjs`.
- El banco común `tests/helpers/contygo-harness.cjs`.
- El simulador `scripts/contygo-mock-server.cjs`.

## Decisiones

- **La clave solo vive en el servidor** (`CONTYGO_API_KEY`), sin prefijo `NEXT_PUBLIC_`. La API no tiene CORS a propósito (guía §2).
- **Sesión en el servidor, no en el navegador.** El navegador solo lleva la cookie httpOnly `cg_checkout`, con un id opaco y firmado. En producción el estado va a **Supabase**, siguiendo el patrón del CRM: tablas con RLS y sin políticas, y funciones `SECURITY DEFINER` que exigen `SUPABASE_ADMIN_SECRET`. En Vercel la memoria no sirve, porque cada instancia tiene la suya. Un control de versión evita que dos pestañas se pisen.
- **`externalRef` = `web-<id de la sesión del chat>`.** Es el mismo en el lead, en el alta y en los webhooks.
- **Claves de idempotencia:**
  - `alta-<sesión>-1-<n>` para cada 1.ª llamada (cada reinicio estrena `n`);
  - `alta-<sesión>-2-<n>-<intento>` para cada código;
  - `reenvio-<contractId>-<n>`.

  Si una llamada se corta, se repite con la misma clave y los mismos bytes. Si la persona reintenta el mismo código tras un corte, se reusa su clave (guía §8).
- **La `signingUrl` nunca se guarda ni se registra.** Solo viaja en la respuesta al navegador de la persona, y solo si es `https` y de contygo. El modelo de IA solo ve la pregunta y la respuesta de elegibilidad.
- **«¡Ya eres cliente nuestro!» solo aparece con `clientCreated: false`, en el 201 posterior al código.** La primera respuesta es idéntica para cualquiera (guía §3.3). `CLIENT_NEEDS_HUMAN` usa siempre el mismo texto neutro.
- **Nunca se envían importes.** El cuerpo solo lleva los campos del OpenAPI y un test comprueba las claves.
- **El rol `lead` no se pide.** Lo ocupa el propio cliente (`clientPartyMode` por defecto). Las demás personas salen de `partyRoles`, respetando `isRequired` y `cardinality`.
- **Webhook:** firma HMAC sobre el cuerpo crudo, ventana de ±300 s y deduplicación por `X-Event-Id`. La tabla de eventos hace de cola y el efecto sobre la sesión se aplica en la misma transacción, que es una sola escritura. Así se responde 2xx en milisegundos. Si la base falla, se responde 503 y contygo reintenta. Nunca redirige.
- **Límites propios, por debajo de los de contygo:**

  | Acción | Por IP | Por sesión |
  |---|---|---|
  | «Contratar» | 10 por hora | 4 por hora |
  | Confirmar el código | 30 por hora | 10 cada 15 min |
  | Lead | 20 por hora | 6 cada 10 min |
  | Reenvío del enlace | — | 3 por hora |

  El CAPTCHA va delante de cada envío de código.
- **Seguro de desarrollo:** fuera de producción, contra el contygo real, solo se lee (catálogo y elegibilidad). Para escribir hay que definir `CONTYGO_ALLOW_WRITES=1`, y solo para la prueba coordinada, porque en producción cada alta crea un cliente, un caso y un contrato reales.

## APUESTAS (sin respaldo todavía)

- **Tipo de pregunta.** El catálogo no dice si una pregunta es de sí/no o de fecha, y la API acepta las dos formas. Se deduce del texto: «¿Cuál es la fecha…?» se trata como fecha. **Hay que pedir a contygo que publique el tipo en `/catalog`.**
- **Texto de la casilla de aceptación** (`terms.ts`, versión `terminos-web-2026-09-28`). Es un borrador pendiente de revisión legal. Si cambia una palabra, cambia la versión: un test compara la huella del texto.

## Discrepancias entre la guía y el OpenAPI (para avisar a contygo)

1. **`CONSENT_CHANNEL_MISMATCH`.** El OpenAPI dice que «un sistema de canal `web` no puede aportar consentimiento de conversación en absoluto». Sin embargo, su enum admite `"web"` y la guía lo exige. Mandamos `"web"`. Si fuera literal, ningún alta web funcionaría.
2. **`NO_SALES_OWNER`.** La guía dice 409 y el OpenAPI, 422. Se tratan igual.
3. **Límites de alta.** La guía da 60 por hora y 300 al día. El OpenAPI da 30 por minuto y 300 por hora por clave.
4. **Primera llamada.** Según el OpenAPI, un cliente nuevo recibe 201 sin código (así funciona WhatsApp). Según la guía, en la web siempre llega primero el 409. El código acepta los dos casos.
5. **Ruta del enlace de firma.** La guía usa `/firma/…` y el ejemplo del 201 del OpenAPI, `/firmar/…`. No se depende de la ruta; solo se exige `https` y el dominio de contygo.
6. **El catálogo real no trae cuotas** en ningún paquete. La ficha muestra la opción de pago solo si existe.

## Checklist de la guía (§11)

- [x] Clave solo en variable de entorno del servidor (`.env.local` está en `.gitignore`).
- [x] CAPTCHA (Turnstile) y límites propios por IP y por sesión delante de «Contratar» y del envío del código.
- [x] Texto de aceptación versionado, en `consent.textVersion`. `consent.at` es el momento en que se marcó la casilla, nunca en el futuro.
- [x] 1.ª llamada → código → 2.ª llamada con el mismo cuerpo, `verificationId`, `verificationCode` y una clave nueva.
- [x] «Ya eres cliente» solo después del código.
- [x] `CLIENT_NEEDS_HUMAN` con el mismo texto neutro.
- [x] La `signingUrl` fuera de logs y fuera del modelo de IA.
- [x] Un corte de red repite con la misma clave; ante un 429 se respeta `Retry-After` y no se reintenta en bucle.
- [x] Webhook: firma, ventana de ±300 s y deduplicación por `X-Event-Id`.
- [ ] **Prueba completa coordinada con contygo** (alta → código → firma → `contract.signed` verificado). Está pendiente: necesita la web publicada, la URL del webhook y el secreto.

## Cómo probar

- **Tests:** `npm test` corre 88 pruebas sin red, con contygo y Turnstile simulados.
- **Recorrido completo sin tocar producción:**
  1. Ejecuta `node scripts/contygo-mock-server.cjs`.
  2. Arranca la web con `CONTYGO_API_BASE=http://127.0.0.1:3999/api/integrations/v1 npm run dev`.
  3. Para ver el CAPTCHA, añade las claves de prueba de Turnstile.
  4. El código válido es `481920`.

  Comprobado el 28-09-2026 en celular (390×844, modo oscuro) y escritorio (1440×900, modo claro): vídeo → preguntas del catálogo → nombre y teléfono → cierre → ficha → código incorrecto («te quedan 4 intentos») → código correcto → firma → gracias → reenvío.
- **Clave real:**

  ```
  curl -s https://contygo.app/api/integrations/v1/me -H "Authorization: Bearer $CONTYGO_API_KEY"
  ```

  Responde 200 con `"channel":"web"`, organización UsaLatinoPrime (comprobado el 28-09-2026).

## Qué queda fuera del recorrido

La entrevista anterior de Visa Juvenil (`/api/agent/visa-intake`, `VisaStatePicker` y las reglas por estado) ya no la usa el recorrido. El código sigue en el proyecto y sus tests pasan. Se puede archivar cuando se decida.
