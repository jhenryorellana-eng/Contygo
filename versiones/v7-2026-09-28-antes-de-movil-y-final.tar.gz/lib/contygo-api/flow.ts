/* ============================================================
   ContyGo · «Contratar» en dos pasos (SOLO servidor)
   Guía §4 y OpenAPI POST /contracts.

   1.ª llamada: siempre 409 CLIENT_VERIFICATION_REQUIRED y un código
      al correo. Se guarda en la sesión el cuerpo EXACTO y el
      verificationId.
   2.ª llamada: el MISMO cuerpo + verificationId + verificationCode,
      con una Idempotency-Key NUEVA por intento → 201 con signingUrl.

   · Nunca se dice «ya eres cliente» antes del código: solo con
     clientCreated=false en el 201.
   · La signingUrl se devuelve al navegador de la persona y a nada más:
     ni sesión, ni logs, ni el modelo de IA.
   ============================================================ */
import { invalidateCatalog, remoteServiceFor } from "./catalog";
import {
  buildContractBody, mapContractResponse, toContractAnswers, toEvaluateAnswers, validateContractForm, type FieldErrors,
} from "./checkout";
import { contygoApi } from "./client";
import { syncLead } from "./lead";
import { updateCheckout } from "./server";
import { externalRefFor, type CheckoutState } from "./store";
import { CONTRACT_TERMS } from "./terms";
import type { CatalogService } from "./types";

/** Lo que ve el navegador. Sin verificationId: ese sobre se queda en el servidor. */
export type BrowserOutcome =
  | { step: "INVALID"; errors: FieldErrors }
  | { step: "NEEDS_ANSWERS" }
  | { step: "ASK_CODE"; maskedEmail: string; expiresAt: string | null }
  | { step: "SIGN"; clientCreated: boolean; caseNumber: string; signingUrl: string; serviceAlreadyLive: string | null; firstName: string }
  | { step: "ALREADY_DONE"; caseNumber: string }
  | { step: "WRONG_CODE"; attemptsLeft: number | null }
  | { step: "RESTART" }
  | { step: "HUMAN" }
  | { step: "NOT_ELIGIBLE" }
  | { step: "UNAVAILABLE" }
  | { step: "INVALID_PARTIES"; role: string | null }
  | { step: "RETRY_LATER"; reason: "destination" | "general" | "busy"; retryAfter: number | null }
  | { step: "ERROR"; code: string };

const logCode = (where: string, code: string) => console.warn(`[contygo] ${where}: ${code}`);

/** Las respuestas guardadas cubren todas las preguntas actuales del servicio. */
function answersComplete(service: CatalogService, state: CheckoutState) {
  return service.eligibilityQuestions.every(question => state.answers?.[question.id] !== undefined);
}

/** «Contratar»: valida, confirma elegibilidad, registra el lead y hace la 1.ª llamada. */
export async function startContract(id: string, state: CheckoutState, input: unknown): Promise<BrowserOutcome> {
  if (state.contract) return { step: "ALREADY_DONE", caseNumber: state.contract.caseNumber };
  const service = await remoteServiceFor(state.localServiceId);
  if (!service) return { step: "UNAVAILABLE" };

  const form = validateContractForm(input, service);
  if (!form.ok) return { step: "INVALID", errors: form.errors };
  if (!answersComplete(service, state)) return { step: "NEEDS_ANSWERS" };
  const answers = state.answers ?? {};

  // Elegibilidad antes del resto: si no hay evaluación válida para estas respuestas, se repite.
  let eligible = state.eligibility && state.serviceId === service.id && state.eligibility.answersKey === JSON.stringify(answers)
    ? state.eligibility.result.eligible : null;
  if (eligible === null) {
    const evaluation = await contygoApi.evaluateEligibility({ serviceId: service.id, answers: toEvaluateAnswers(service.eligibilityQuestions, answers) });
    if (evaluation.status !== 200 || !evaluation.data) { logCode("elegibilidad", evaluation.error?.code ?? `HTTP_${evaluation.status}`); return { step: "RETRY_LATER", reason: "busy", retryAfter: evaluation.retryAfter }; }
    const result = evaluation.data;
    eligible = result.eligible;
    state = (await updateCheckout(id, current => ({ ...current, serviceId: service.id, eligibility: { result, answersKey: JSON.stringify(answers), at: new Date().toISOString() } }))).state;
  }
  if (!eligible) return { step: "NOT_ELIGIBLE" };

  // El lead se actualiza con el nombre completo y el correo. Si falla, no bloquea la venta.
  const lead = await syncLead(id, state, { fullName: form.value.fullName, phoneE164: form.value.phoneE164, email: form.value.email });

  const body = buildContractBody({
    externalRef: externalRefFor(id),
    serviceId: service.id,
    form: form.value,
    eligibilityAnswers: toContractAnswers(service.eligibilityQuestions, answers),
    termsVersion: CONTRACT_TERMS.version,
  });
  // El número de intento se reserva ANTES de llamar: un reinicio nunca reusa una clave gastada.
  const reserved = await updateCheckout(id, current => ({
    ...current,
    startSeq: current.startSeq + 1,
    start: undefined,
    lead: { fullName: form.value.fullName, phoneE164: form.value.phoneE164, ...(lead.ok ? { leadId: lead.leadId } : current.lead?.leadId ? { leadId: current.lead.leadId } : {}), at: new Date().toISOString() },
  }));
  const seq = reserved.state.startSeq;
  const response = await contygoApi.createContract(body, `alta-${id}-1-${seq}`);
  const outcome = mapContractResponse(response);

  switch (outcome.step) {
    case "ASK_CODE":
      await updateCheckout(id, current => ({
        ...current,
        start: { seq, body, verificationId: outcome.verificationId, maskedEmail: outcome.maskedEmail, expiresAt: outcome.expiresAt, at: new Date().toISOString(), attempts: 0 },
      }));
      return { step: "ASK_CODE", maskedEmail: outcome.maskedEmail, expiresAt: outcome.expiresAt };
    case "SIGN": // Un canal que no exige código respondería 201 directamente (OpenAPI). Se acepta igual.
      await saveContract(id, outcome.created.contractId, outcome.created.caseId, outcome.created.caseNumber, outcome.created.clientCreated, outcome.serviceAlreadyLive);
      return { step: "SIGN", clientCreated: outcome.created.clientCreated, caseNumber: outcome.created.caseNumber, signingUrl: outcome.created.signingUrl, serviceAlreadyLive: outcome.serviceAlreadyLive, firstName: form.value.nameParts.firstName };
    case "UNAVAILABLE":
      invalidateCatalog();
      return outcome;
    case "ERROR":
      logCode("alta (1.ª llamada)", outcome.code);
      if (outcome.code === "NETWORK") return { step: "RETRY_LATER", reason: "busy", retryAfter: 5 };
      return outcome;
    case "WRONG_CODE":
    case "RESTART":
      logCode("alta (1.ª llamada) inesperada", outcome.step);
      return { step: "ERROR", code: outcome.step };
    default:
      return outcome;
  }
}

async function saveContract(id: string, contractId: string, caseId: string, caseNumber: string, clientCreated: boolean, serviceAlreadyLive: string | null) {
  await updateCheckout(id, current => ({
    ...current,
    start: undefined,
    contract: { contractId, caseId, caseNumber, clientCreated, serviceAlreadyLive, at: new Date().toISOString() },
  }));
}

/** 2.ª llamada: el cuerpo guardado, sin tocar, más el sobre y el código. */
export async function confirmContract(id: string, state: CheckoutState, rawCode: unknown): Promise<BrowserOutcome> {
  if (state.contract) return { step: "ALREADY_DONE", caseNumber: state.contract.caseNumber };
  const start = state.start;
  if (!start) return { step: "RESTART" };
  const code = typeof rawCode === "string" ? rawCode.replace(/\s/g, "") : "";
  if (!/^\d{6}$/.test(code)) return { step: "INVALID", errors: { code: "El código tiene 6 dígitos." } };

  // Un reintento con el mismo código tras un corte reusa su clave; un código nuevo estrena la suya.
  const reuse = start.pending?.code === code ? start.pending : null;
  const attempt = reuse ? start.attempts : start.attempts + 1;
  const key = reuse?.key ?? `alta-${id}-2-${start.seq}-${attempt}`;
  if (!reuse) await updateCheckout(id, current => current.start?.seq === start.seq ? { ...current, start: { ...current.start, attempts: attempt, pending: { code, key } } } : current);

  const response = await contygoApi.createContract({ ...start.body, verificationId: start.verificationId, verificationCode: code }, key);
  const outcome = mapContractResponse(response);
  const clearPending = () => updateCheckout(id, current => current.start?.seq === start.seq ? { ...current, start: { ...current.start, pending: undefined } } : current);
  const endVerification = () => updateCheckout(id, current => current.start?.seq === start.seq ? { ...current, start: undefined } : current);

  switch (outcome.step) {
    case "SIGN":
      await saveContract(id, outcome.created.contractId, outcome.created.caseId, outcome.created.caseNumber, outcome.created.clientCreated, outcome.serviceAlreadyLive);
      return {
        step: "SIGN",
        clientCreated: outcome.created.clientCreated,
        caseNumber: outcome.created.caseNumber,
        signingUrl: outcome.created.signingUrl,
        serviceAlreadyLive: outcome.serviceAlreadyLive,
        firstName: start.body.client.nameParts.firstName,
      };
    case "WRONG_CODE":
      await clearPending();
      return outcome;
    case "RETRY_LATER":
      // IN_PROGRESS y 503: la misma clave sigue viva. 429: nada se creó y el siguiente intento estrena clave.
      if (outcome.reason !== "busy") await clearPending();
      return outcome;
    case "ERROR":
      if (outcome.code === "NETWORK") return { step: "RETRY_LATER", reason: "busy", retryAfter: 5 };
      logCode("alta (2.ª llamada)", outcome.code);
      await endVerification();
      return outcome;
    case "ASK_CODE":
      logCode("alta (2.ª llamada) inesperada", outcome.step);
      await endVerification();
      return { step: "RESTART" };
    case "UNAVAILABLE":
      invalidateCatalog();
      await endVerification();
      return outcome;
    default: // RESTART, HUMAN, NOT_ELIGIBLE, INVALID_PARTIES: esta verificación ya no sirve.
      await endVerification();
      return outcome;
  }
}
