/* ============================================================
   ContyGo · lead (SOLO servidor)
   En cuanto hay nombre y teléfono: PUT /leads/{externalRef}, con
   externalRef = «web-<id de la sesión del chat>», source "web" y la
   atribución (URL y UTM). Idempotente: repetirlo actualiza el mismo.
   aiSummary nunca lleva datos sensibles ni las respuestas.
   ============================================================ */
import { CONTYGO_SERVICES } from "@/lib/contygo-catalog";
import { contygoApi } from "./client";
import { externalRefFor, type CheckoutState } from "./store";
import type { Attribution, UpsertLeadBody } from "./types";

/** Solo URL http(s) sin query ni fragmento, y claves utm_* acotadas (máx. 20). */
export function sanitizeAttribution(input: unknown): CheckoutState["attribution"] {
  if (!input || typeof input !== "object" || Array.isArray(input)) return undefined;
  const raw = input as { sourceUrl?: unknown; utm?: unknown };
  const result: NonNullable<CheckoutState["attribution"]> = {};
  if (typeof raw.sourceUrl === "string" && raw.sourceUrl.length <= 2000) {
    try {
      const url = new URL(raw.sourceUrl);
      if (url.protocol === "https:" || url.protocol === "http:") result.sourceUrl = `${url.origin}${url.pathname}`.slice(0, 500);
    } catch { /* Se ignora: la atribución es opcional. */ }
  }
  if (raw.utm && typeof raw.utm === "object" && !Array.isArray(raw.utm)) {
    const utm: Record<string, string> = {};
    for (const [key, value] of Object.entries(raw.utm as Record<string, unknown>)) {
      if (Object.keys(utm).length >= 20) break;
      if (/^utm_[a-z0-9_]{1,40}$/.test(key) && typeof value === "string" && value.trim()) utm[key] = value.trim().slice(0, 200);
    }
    if (Object.keys(utm).length) result.utm = utm;
  }
  return Object.keys(result).length ? result : undefined;
}

export function leadSummary(state: CheckoutState) {
  const service = CONTYGO_SERVICES.find(item => item.id === state.localServiceId)?.name ?? state.serviceSlug;
  const verdict = !state.eligibility ? "Aún sin respuestas de elegibilidad."
    : state.eligibility.result.eligible ? "Respondió las preguntas del servicio: califica." : "Respondió las preguntas del servicio: requiere revisión de un asesor.";
  return `Web · ${service}. ${verdict}`;
}

export function buildLeadBody(state: CheckoutState, person: { fullName: string; phoneE164: string; email?: string }): UpsertLeadBody {
  const attribution: Attribution | undefined = state.attribution ? { ...state.attribution } : undefined;
  return {
    fullName: person.fullName.slice(0, 120),
    phoneE164: person.phoneE164,
    source: "web",
    ...(person.email ? { email: person.email } : {}),
    ...(attribution ? { attribution } : {}),
    aiSummary: leadSummary(state),
  };
}

/** Devuelve el leadId o el código de error (solo el código: sin datos de la persona). */
export async function syncLead(id: string, state: CheckoutState, person: { fullName: string; phoneE164: string; email?: string }) {
  const response = await contygoApi.upsertLead(externalRefFor(id), buildLeadBody(state, person));
  if ((response.status === 200 || response.status === 201) && response.data?.leadId) return { ok: true as const, leadId: response.data.leadId };
  const code = response.error?.code ?? `HTTP_${response.status}`;
  console.warn(`[contygo] lead no registrado: ${code}`);
  return { ok: false as const, code, retryAfter: response.retryAfter };
}
