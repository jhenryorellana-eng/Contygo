/* ============================================================
   ContyGo · utilidades de las rutas de contratación (SOLO servidor)
   Cookie de sesión firmada, lectura acotada del cuerpo, origen,
   límites por IP y por sesión y verificación del CAPTCHA.
   ============================================================ */
import { createHash, createHmac, randomBytes, randomUUID, timingSafeEqual } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { isSameOriginIntakeRequest } from "@/lib/agent/visa-intake";
import { CatalogUnavailableError } from "./catalog";
import { ContygoNotConfiguredError } from "./client";
import { getCheckoutStore, StoreUnavailableError, type CheckoutState, type StoredCheckout } from "./store";

export const CHECKOUT_COOKIE = "cg_checkout";
const COOKIE_DAYS = 30;
const NO_STORE = { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };

export const json = (body: unknown, status = 200, headers: Record<string, string> = {}) =>
  NextResponse.json(body, { status, headers: { ...NO_STORE, ...headers } });

export const fail = (error: string, status: number, extra: Record<string, unknown> = {}, headers: Record<string, string> = {}) =>
  json({ ok: false, error, ...extra }, status, headers);

/** Falta de configuración o de un servicio externo → 503 con un código, nunca con detalles. */
export async function guarded(handler: () => Promise<NextResponse>): Promise<NextResponse> {
  try {
    return await handler();
  } catch (error) {
    const code = error instanceof ContygoNotConfiguredError ? "contygo_not_configured"
      : error instanceof CatalogUnavailableError ? "catalog_unavailable"
      : error instanceof StoreUnavailableError ? "session_unavailable" : "internal";
    console.warn(`[contygo] ${code}`);
    return fail(code, 503);
  }
}

export function clientIp(req: NextRequest): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0]!.trim().slice(0, 64);
  return (req.headers.get("x-real-ip") ?? "local").slice(0, 64);
}

// ---------------- Cookie firmada con un id opaco ----------------

function cookieKey(): string | null {
  const secret = process.env.CONTYGO_SESSION_SECRET || process.env.CONTYGO_API_KEY;
  return secret ? createHash("sha256").update(`contygo-checkout-cookie:${secret}`).digest("hex") : null;
}
const sign = (id: string, key: string) => createHmac("sha256", key).update(id).digest("base64url");

export const newCheckoutId = () => randomBytes(18).toString("base64url");

export function readCheckoutId(req: NextRequest): string | null {
  const key = cookieKey();
  const raw = req.cookies.get(CHECKOUT_COOKIE)?.value;
  if (!key || !raw) return null;
  const dot = raw.lastIndexOf(".");
  if (dot < 0) return null;
  const id = raw.slice(0, dot), signature = Buffer.from(raw.slice(dot + 1)), expected = Buffer.from(sign(id, key));
  if (signature.length !== expected.length || !timingSafeEqual(signature, expected)) return null;
  return /^[A-Za-z0-9_-]{16,64}$/.test(id) ? id : null;
}

export function setCheckoutCookie(res: NextResponse, id: string) {
  const key = cookieKey();
  if (!key) return;
  res.cookies.set(CHECKOUT_COOKIE, `${id}.${sign(id, key)}`, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: COOKIE_DAYS * 86_400,
  });
}

export async function loadCheckout(req: NextRequest): Promise<{ id: string; stored: StoredCheckout } | null> {
  const id = readCheckoutId(req);
  if (!id) return null;
  const stored = await getCheckoutStore().get(id);
  return stored ? { id, stored } : null;
}

/** Guarda con control de versión: dos pestañas no se pisan en silencio. */
export async function saveCheckout(id: string, state: CheckoutState, version: number): Promise<number> {
  const next = await getCheckoutStore().put(id, state, version);
  if (next === null) throw new StoreUnavailableError("conflict");
  return next;
}

/**
 * La sesión de ESTA conversación. Un servicio distinto o una contratación ya
 * cerrada empiezan otra: cada conversación es un lead con su propio externalRef.
 */
export async function ensureCheckout(req: NextRequest, localServiceId: string, serviceSlug: string): Promise<{ id: string; stored: StoredCheckout; created: boolean }> {
  const found = await loadCheckout(req);
  if (found && found.stored.state.localServiceId === localServiceId && !found.stored.state.contract) return { ...found, created: false };
  const id = newCheckoutId();
  const state: CheckoutState = { v: 1, createdAt: new Date().toISOString(), localServiceId, serviceSlug, startSeq: 0, resends: 0 };
  const version = await saveCheckout(id, state, 0);
  return { id, stored: { state, version }, created: true };
}

/** Relee y aplica un cambio; si otra petición guardó antes, lo intenta una vez más. */
export async function updateCheckout(id: string, change: (state: CheckoutState) => CheckoutState): Promise<StoredCheckout> {
  const store = getCheckoutStore();
  for (let attempt = 0; attempt < 2; attempt++) {
    const current = await store.get(id);
    if (!current) throw new StoreUnavailableError("missing");
    const state = change(current.state);
    const version = await store.put(id, state, current.version);
    if (version !== null) return { state, version };
  }
  throw new StoreUnavailableError("conflict");
}

// ---------------- Peticiones del navegador ----------------

const MAX_BODY_BYTES = 32 * 1024;

/** Mismo origen, JSON y tamaño acotado. Devuelve el cuerpo o una respuesta de error. */
export async function readBrowserJson(req: NextRequest): Promise<{ body: Record<string, unknown> } | { response: NextResponse }> {
  if (!isSameOriginIntakeRequest(req)) return { response: fail("forbidden_origin", 403) };
  if (req.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== "application/json") return { response: fail("json_required", 415) };
  if (Number(req.headers.get("content-length")) > MAX_BODY_BYTES) return { response: fail("too_large", 413) };
  const reader = req.body?.getReader();
  if (!reader) return { response: fail("bad_json", 400) };
  try {
    const chunks: Uint8Array[] = [];
    let size = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BODY_BYTES) { await reader.cancel(); return { response: fail("too_large", 413) }; }
      chunks.push(value);
    }
    const body: unknown = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!body || typeof body !== "object" || Array.isArray(body)) return { response: fail("bad_json", 400) };
    return { body: body as Record<string, unknown> };
  } catch {
    return { response: fail("bad_json", 400) };
  } finally {
    reader.releaseLock();
  }
}

/** Nuestros propios techos, por debajo de los de contygo. Todos deben pasar. */
export async function checkLimits(rules: { key: string; windowSeconds: number; max: number }[]): Promise<NextResponse | null> {
  const store = getCheckoutStore();
  for (const rule of rules) {
    const result = await store.hit(rule.key, rule.windowSeconds, rule.max);
    if (!result.allowed) return fail("rate_limited", 429, { retryAfter: result.retryAfter }, { "Retry-After": String(result.retryAfter) });
  }
  return null;
}

// ---------------- CAPTCHA (Cloudflare Turnstile) ----------------
// https://developers.cloudflare.com/turnstile/get-started/server-side-validation/
// Cada token vale una vez y caduca a los 5 minutos.

export const CAPTCHA_ACTION = "contratar";

export async function verifyCaptcha(token: unknown, ip: string): Promise<{ ok: boolean; code: string }> {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret) {
    // Sin clave en producción no se contrata: el CAPTCHA es obligatorio delante del código.
    return process.env.NODE_ENV === "production" ? { ok: false, code: "captcha_not_configured" } : { ok: true, code: "captcha_skipped_dev" };
  }
  if (typeof token !== "string" || !token || token.length > 2048) return { ok: false, code: "captcha_missing" };
  try {
    const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(8000),
      body: JSON.stringify({ secret, response: token, ...(ip !== "local" ? { remoteip: ip } : {}), idempotency_key: randomUUID() }),
    });
    const data = await response.json() as { success?: boolean; action?: string };
    if (data.success !== true) return { ok: false, code: "captcha_failed" };
    if (data.action && data.action !== CAPTCHA_ACTION) return { ok: false, code: "captcha_failed" };
    return { ok: true, code: "captcha_ok" };
  } catch {
    return { ok: false, code: "captcha_unavailable" };
  }
}
