/* ============================================================
   ContyGo · sesión de contratación en el SERVIDOR
   Aquí vive lo que no puede tocar el navegador: el cuerpo exacto
   de la 1.ª llamada, el verificationId, el contractId y el
   caseNumber. El navegador solo lleva una cookie con un id opaco.

   · Producción (Vercel): Supabase, vía RPC protegidas con
     SUPABASE_ADMIN_SECRET (supabase/contygo-contratacion.sql).
     La memoria no sirve: cada instancia tiene la suya.
   · Desarrollo y tests: memoria del proceso.
   CONTYGO_SESSION_STORE=supabase|memory fuerza uno u otro.

   La signingUrl NUNCA se guarda: es una credencial al portador.
   ============================================================ */
import type { AnswerValue, ContractBody, ContractStatus, EligibilityResult } from "./types";

export interface CheckoutState {
  v: 1;
  createdAt: string;
  /** Servicio de la landing (lib/contygo-catalog) y su equivalente en contygo. */
  localServiceId: string;
  serviceSlug: string;
  serviceId?: string;
  answers?: Record<string, AnswerValue>;
  eligibility?: { result: EligibilityResult; answersKey: string; at: string };
  lead?: { fullName: string; phoneE164: string; leadId?: string; at: string };
  attribution?: { sourceUrl?: string; utm?: Record<string, string> };
  /** Cada «Contratar» (y cada reinicio tras caducar el código) suma uno. */
  startSeq: number;
  start?: {
    seq: number;
    body: ContractBody;
    verificationId: string;
    maskedEmail: string;
    expiresAt: string | null;
    at: string;
    /** Intentos de código enviados en esta verificación. */
    attempts: number;
    /** Intento en vuelo: si se corta, el reintento con el mismo código reusa su clave. */
    pending?: { code: string; key: string };
  };
  contract?: { contractId: string; caseId: string; caseNumber: string; clientCreated: boolean; serviceAlreadyLive: string | null; at: string };
  lastStatus?: { at: string; value: ContractStatus };
  resends: number;
  events?: { caseCreatedAt?: string; contractSignedAt?: string; downpaymentConfirmedAt?: string; amountCents?: number };
}

export interface StoredCheckout { state: CheckoutState; version: number }

export interface CheckoutStore {
  get(id: string): Promise<StoredCheckout | null>;
  /** Crea (version 0) o actualiza si nadie la cambió antes. Devuelve la versión nueva o null si hubo conflicto. */
  put(id: string, state: CheckoutState, version: number): Promise<number | null>;
  /** Ventana fija. allowed=false trae los segundos que faltan. */
  hit(key: string, windowSeconds: number, max: number): Promise<{ allowed: boolean; retryAfter: number }>;
  /** Registra el evento y aplica su efecto en la sesión, en un paso. "duplicate" si ya se había visto. */
  recordWebhook(event: { eventId: string; type: string; externalRef: string | null; occurredAt: string; payload: unknown }): Promise<"new" | "duplicate">;
}

export class StoreUnavailableError extends Error {
  constructor(readonly code: string) { super(`sesión no disponible: ${code}`); this.name = "StoreUnavailableError"; }
}

/** El id de la sesión viaja como externalRef «web-<id>». */
export const externalRefFor = (id: string) => `web-${id}`;
export const idFromExternalRef = (ref: string | null | undefined) => ref && /^web-[A-Za-z0-9_-]{16,64}$/.test(ref) ? ref.slice(4) : null;

/** Efecto de cada aviso sobre la sesión. Mismo criterio en memoria y en SQL. */
export function applyEvent(state: CheckoutState, type: string, occurredAt: string, data: Record<string, unknown>): CheckoutState {
  const events = { ...(state.events ?? {}) };
  if (type === "case.created") events.caseCreatedAt = occurredAt;
  if (type === "contract.signed") events.contractSignedAt = typeof data.signedAt === "string" ? data.signedAt : occurredAt;
  if (type === "downpayment.confirmed") {
    events.downpaymentConfirmedAt = occurredAt;
    if (typeof data.amountCents === "number") events.amountCents = data.amountCents;
  }
  return { ...state, events };
}

// ---------------- Memoria (desarrollo y tests) ----------------

export function createMemoryStore(): CheckoutStore {
  const rows = new Map<string, StoredCheckout>();
  const hits = new Map<string, { start: number; count: number }>();
  const events = new Set<string>();
  const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value));
  return {
    async get(id) { const row = rows.get(id); return row ? clone(row) : null; },
    async put(id, state, version) {
      const current = rows.get(id);
      if ((current?.version ?? 0) !== version) return null;
      const next = version + 1;
      rows.set(id, { state: clone(state), version: next });
      return next;
    },
    async hit(key, windowSeconds, max) {
      const now = Date.now(), windowMs = windowSeconds * 1000;
      const entry = hits.get(key);
      if (!entry || now - entry.start >= windowMs) { hits.set(key, { start: now, count: 1 }); return { allowed: true, retryAfter: 0 }; }
      if (entry.count >= max) return { allowed: false, retryAfter: Math.max(1, Math.ceil((entry.start + windowMs - now) / 1000)) };
      entry.count += 1;
      return { allowed: true, retryAfter: 0 };
    },
    async recordWebhook(event) {
      if (events.has(event.eventId)) return "duplicate";
      events.add(event.eventId);
      const id = idFromExternalRef(event.externalRef);
      const row = id ? rows.get(id) : undefined;
      if (id && row) {
        const data = (event.payload as { data?: Record<string, unknown> })?.data ?? {};
        rows.set(id, { state: applyEvent(row.state, event.type, event.occurredAt, data), version: row.version + 1 });
      }
      return "new";
    },
  };
}

// ---------------- Supabase (producción) ----------------

function createSupabaseStore(): CheckoutStore {
  const url = (process.env.SUPABASE_URL ?? "").replace(/\/+$/, "");
  const anon = process.env.SUPABASE_ANON_KEY ?? "";
  const secret = process.env.SUPABASE_ADMIN_SECRET ?? "";
  async function rpc<T>(fn: string, body: Record<string, unknown>): Promise<T> {
    if (!url || !anon || !secret) throw new StoreUnavailableError("not_configured");
    let response: Response;
    try {
      response = await fetch(`${url}/rest/v1/rpc/${fn}`, {
        method: "POST",
        headers: { apikey: anon, Authorization: `Bearer ${anon}`, "Content-Type": "application/json" },
        cache: "no-store",
        signal: AbortSignal.timeout(6000),
        body: JSON.stringify({ p_secret: secret, ...body }),
      });
    } catch { throw new StoreUnavailableError("network"); }
    const text = await response.text();
    if (!response.ok) throw new StoreUnavailableError(`http_${response.status}`);
    return (text ? JSON.parse(text) : null) as T;
  }
  return {
    async get(id) {
      const rows = await rpc<{ state: CheckoutState; version: number }[]>("ulp_cg_checkout_get", { p_id: id });
      return rows?.[0] ? { state: rows[0].state, version: rows[0].version } : null;
    },
    async put(id, state, version) {
      const next = await rpc<number | null>("ulp_cg_checkout_put", { p_id: id, p_state: state, p_version: version });
      return typeof next === "number" ? next : null;
    },
    async hit(key, windowSeconds, max) {
      const rows = await rpc<{ allowed: boolean; retry_after: number }[]>("ulp_cg_hit", { p_key: key, p_window: windowSeconds, p_max: max });
      return { allowed: Boolean(rows?.[0]?.allowed), retryAfter: rows?.[0]?.retry_after ?? 60 };
    },
    async recordWebhook(event) {
      const inserted = await rpc<boolean>("ulp_cg_webhook_record", {
        p_event_id: event.eventId, p_type: event.type, p_external_ref: event.externalRef, p_occurred_at: event.occurredAt, p_payload: event.payload,
      });
      return inserted ? "new" : "duplicate";
    },
  };
}

// ---------------- Elección ----------------

// En desarrollo Next compila cada ruta por separado: el almacén se ancla a
// globalThis para que /iniciar y /confirmar vean la misma memoria.
const holder = globalThis as typeof globalThis & { __contygoCheckoutStore?: CheckoutStore | null };

export function getCheckoutStore(): CheckoutStore {
  if (holder.__contygoCheckoutStore) return holder.__contygoCheckoutStore;
  const choice = process.env.CONTYGO_SESSION_STORE ?? (process.env.NODE_ENV === "production" ? "supabase" : "memory");
  holder.__contygoCheckoutStore = choice === "supabase" ? createSupabaseStore() : createMemoryStore();
  return holder.__contygoCheckoutStore;
}

/** Solo tests. */
export function setCheckoutStore(store: CheckoutStore | null) { holder.__contygoCheckoutStore = store; }
