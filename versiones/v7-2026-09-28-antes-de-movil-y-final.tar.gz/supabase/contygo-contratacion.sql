-- ============================================================
-- ContyGo · contratación por API: sesión del servidor, límites
-- propios y registro de webhooks.
-- Ejecutar DESPUÉS de crm-functions.sql (usa ulp_check_secret).
--
-- Diseño (igual que el CRM):
--  · Tablas privadas con RLS y SIN políticas: nadie las lee por la API.
--  · Solo funciones SECURITY DEFINER que exigen SUPABASE_ADMIN_SECRET.
--  · Nunca se guarda la signingUrl (es una credencial al portador).
-- ============================================================

-- ---- Sesión de cada conversación (id opaco de la cookie cg_checkout) ----
create table if not exists public.ulp_cg_checkouts (
  id         text primary key check (id ~ '^[A-Za-z0-9_-]{16,64}$'),
  version    integer not null default 1,
  state      jsonb not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  expires_at timestamptz not null default now() + interval '90 days'
);
alter table public.ulp_cg_checkouts enable row level security;
create index if not exists ulp_cg_checkouts_expires_idx on public.ulp_cg_checkouts (expires_at);

-- ---- Contadores de ventana fija (por IP y por sesión) ----
create table if not exists public.ulp_cg_rate_hits (
  key          text primary key check (char_length(key) <= 200),
  window_start timestamptz not null,
  hits         integer not null
);
alter table public.ulp_cg_rate_hits enable row level security;

-- ---- Webhooks recibidos: la tabla es la cola y el registro de dedupe ----
create table if not exists public.ulp_cg_webhook_events (
  event_id     text primary key check (char_length(event_id) <= 200),
  type         text not null,
  external_ref text,
  occurred_at  timestamptz,
  payload      jsonb not null,
  received_at  timestamptz not null default now(),
  applied      boolean not null default false
);
alter table public.ulp_cg_webhook_events enable row level security;

-- ---- Leer una sesión ----
create or replace function public.ulp_cg_checkout_get(p_secret text, p_id text)
returns table (state jsonb, version integer)
language plpgsql security definer set search_path = public
as $$
begin
  perform public.ulp_check_secret(p_secret);
  return query select c.state, c.version from public.ulp_cg_checkouts c where c.id = p_id and c.expires_at > now();
end; $$;

-- ---- Crear (p_version = 0) o actualizar con control de versión ----
-- Devuelve la versión nueva, o null si otra petición la cambió antes.
create or replace function public.ulp_cg_checkout_put(p_secret text, p_id text, p_state jsonb, p_version integer)
returns integer
language plpgsql security definer set search_path = public
as $$
declare v_next integer;
begin
  perform public.ulp_check_secret(p_secret);
  if p_version = 0 then
    insert into public.ulp_cg_checkouts (id, state) values (p_id, p_state)
    on conflict (id) do nothing
    returning version into v_next;
  else
    update public.ulp_cg_checkouts
       set state = p_state, version = version + 1, updated_at = now(), expires_at = now() + interval '90 days'
     where id = p_id and version = p_version
    returning version into v_next;
  end if;
  return v_next;
end; $$;

-- ---- Límite de ventana fija. allowed=false trae los segundos que faltan ----
create or replace function public.ulp_cg_hit(p_secret text, p_key text, p_window integer, p_max integer)
returns table (allowed boolean, retry_after integer)
language plpgsql security definer set search_path = public
as $$
declare v_row public.ulp_cg_rate_hits;
begin
  perform public.ulp_check_secret(p_secret);
  insert into public.ulp_cg_rate_hits as r (key, window_start, hits) values (p_key, now(), 1)
  on conflict (key) do update
    set window_start = case when r.window_start + make_interval(secs => p_window) <= now() then now() else r.window_start end,
        hits         = case when r.window_start + make_interval(secs => p_window) <= now() then 1 else r.hits + 1 end
  returning * into v_row;
  if v_row.hits > p_max then
    return query select false, greatest(1, ceil(extract(epoch from (v_row.window_start + make_interval(secs => p_window) - now())))::integer);
  else
    return query select true, 0;
  end if;
end; $$;

-- ---- Registrar un webhook y aplicar su efecto en la sesión, en una transacción ----
-- true = nuevo; false = ya se había recibido (mismo X-Event-Id).
create or replace function public.ulp_cg_webhook_record(p_secret text, p_event_id text, p_type text, p_external_ref text, p_occurred_at timestamptz, p_payload jsonb)
returns boolean
language plpgsql security definer set search_path = public
as $$
declare
  v_id text;
  v_data jsonb := coalesce(p_payload -> 'data', '{}'::jsonb);
  v_events jsonb;
begin
  perform public.ulp_check_secret(p_secret);
  insert into public.ulp_cg_webhook_events (event_id, type, external_ref, occurred_at, payload)
  values (p_event_id, p_type, p_external_ref, p_occurred_at, p_payload)
  on conflict (event_id) do nothing;
  if not found then return false; end if;

  -- externalRef = 'web-<id de la sesión>' (lib/contygo-api/store.ts · applyEvent hace lo mismo en memoria).
  if p_external_ref ~ '^web-[A-Za-z0-9_-]{16,64}$' then
    v_id := substr(p_external_ref, 5);
    select coalesce(state -> 'events', '{}'::jsonb) into v_events from public.ulp_cg_checkouts where id = v_id for update;
    if found then
      if p_type = 'case.created' then
        v_events := v_events || jsonb_build_object('caseCreatedAt', p_occurred_at);
      elsif p_type = 'contract.signed' then
        v_events := v_events || jsonb_build_object('contractSignedAt', coalesce(v_data ->> 'signedAt', p_occurred_at::text));
      elsif p_type = 'downpayment.confirmed' then
        v_events := v_events || jsonb_build_object('downpaymentConfirmedAt', p_occurred_at)
                             || case when jsonb_typeof(v_data -> 'amountCents') = 'number' then jsonb_build_object('amountCents', v_data -> 'amountCents') else '{}'::jsonb end;
      end if;
      update public.ulp_cg_checkouts
         set state = jsonb_set(state, '{events}', v_events), version = version + 1, updated_at = now()
       where id = v_id;
    end if;
  end if;
  update public.ulp_cg_webhook_events set applied = true where event_id = p_event_id;
  return true;
end; $$;

revoke all on function public.ulp_cg_checkout_get(text, text) from public, anon, authenticated;
revoke all on function public.ulp_cg_checkout_put(text, text, jsonb, integer) from public, anon, authenticated;
revoke all on function public.ulp_cg_hit(text, text, integer, integer) from public, anon, authenticated;
revoke all on function public.ulp_cg_webhook_record(text, text, text, text, timestamptz, jsonb) from public, anon, authenticated;
grant execute on function public.ulp_cg_checkout_get(text, text) to anon;
grant execute on function public.ulp_cg_checkout_put(text, text, jsonb, integer) to anon;
grant execute on function public.ulp_cg_hit(text, text, integer, integer) to anon;
grant execute on function public.ulp_cg_webhook_record(text, text, text, text, timestamptz, jsonb) to anon;

-- Limpieza opcional (p. ej. semanal): sesiones caducadas y contadores viejos.
-- delete from public.ulp_cg_checkouts where expires_at < now();
-- delete from public.ulp_cg_rate_hits where window_start < now() - interval '2 days';
