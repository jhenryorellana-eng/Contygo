const test = require('node:test');
const assert = require('node:assert/strict');
const { ids, SIGNING_URL, VERIFICATION_ID, mockFetch, contygoDefaults, browser, freshModules } = require('./helpers/contygo-harness.cjs');
const { signWebhook } = require('../lib/contygo-api/webhook.ts');

const agentServer = require('../lib/agent/server.ts');
const intakeRoute = require('../app/api/agent/service-intake/route.ts');
const leadRoute = require('../app/api/contratar/lead/route.ts');
const serviceRoute = require('../app/api/contratar/servicio/route.ts');
const startRoute = require('../app/api/contratar/iniciar/route.ts');
const confirmRoute = require('../app/api/contratar/confirmar/route.ts');
const statusRoute = require('../app/api/contratar/estado/route.ts');
const resendRoute = require('../app/api/contratar/reenviar/route.ts');
const webhookRoute = require('../app/api/webhooks/contygo/route.ts');

const contractForm = (patch = {}) => ({
  firstName: 'Ana', middleName: 'María', lastName: 'Pérez López', email: 'ana.perez@gmail.com', phone: '+13055550199',
  address: { line1: '100 Main St', apartment: '4B', city: 'Miami', state: 'FL', zip: '33101' }, locale: 'es',
  servicePlanId: ids.visaPlan, parties: [{ role: 'minor', firstName: 'Luis', lastName: 'Pérez', dateOfBirth: '2014-04-03' }],
  consent: { accepted: true, at: new Date(Date.now() - 30_000).toISOString() }, ...patch,
});

/** Captura todo lo que se escribe en consola durante la prueba. */
function captureConsole() {
  const lines = [];
  const original = { log: console.log, info: console.info, warn: console.warn, error: console.error };
  for (const level of Object.keys(original)) console[level] = (...args) => lines.push(args.map(String).join(' '));
  return { lines, restore: () => Object.assign(console, original) };
}

async function post(route, b, url, body) { return b.keep(await route.POST(b.request(url, body))); }

/** Recorre el chat de Visa Juvenil hasta completar sus preguntas. */
async function interview(b, answer = true) {
  const greeting = await (await post(intakeRoute, b, '/api/agent/service-intake', { serviceId: 'visa-juvenil', answers: {} })).json();
  const done = await (await post(intakeRoute, b, '/api/agent/service-intake', { serviceId: 'visa-juvenil', answers: {}, field: greeting.field, answer })).json();
  return { greeting, done };
}

async function toCode(b, net, patch) {
  await interview(b);
  const res = await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(patch), captchaToken: 'token-ok' });
  return (await res.json()).outcome;
}

test.beforeEach(() => { freshModules(); delete process.env.TURNSTILE_SECRET_KEY; process.env.CONTYGO_WEBHOOK_SECRET = 'whsec_prueba'; });

test('las preguntas del chat salen del catálogo y al terminar se evalúa la elegibilidad en contygo', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const b = browser();
  const { greeting, done } = await interview(b);
  assert.equal(greeting.question.id, ids.visaQ);
  assert.equal(greeting.question.text, '¿El menor tiene menos de 21 años y no está casado?');
  assert.equal(greeting.question.kind, 'yesno');
  assert.equal(greeting.total, 1);
  assert.ok(greeting.message.includes(greeting.question.text));
  assert.ok(greeting.scripts.includes(greeting.message), 'la locución del saludo se precarga');
  assert.ok(b.jar.get('cg_checkout'), 'la conversación tiene su sesión en el servidor');
  assert.equal(done.complete, true);
  assert.equal(done.eligible, true);
  assert.equal(done.guidance.status, 'potential');
  const evaluate = net.calls.find(call => call.path === '/eligibility/evaluate');
  assert.deepEqual(evaluate.json, { serviceId: ids.visa, answers: [{ questionId: ids.visaQ, value: true }] });
  // Un servicio sin preguntas se completa sin preguntar nada.
  const itin = await (await post(intakeRoute, browser(), '/api/agent/service-intake', { serviceId: 'itin', answers: {} })).json();
  assert.equal(itin.total, 0);
  assert.equal(itin.complete, true);
});

test('la respuesta negativa no cierra el recorrido; la ficha sabe que no califica y no contrata', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const b = browser();
  const { done } = await interview(b, 'no');
  assert.equal(done.complete, true);
  assert.equal(done.eligible, false);
  assert.equal(done.guidance.status, 'review');
  const view = await (await post(serviceRoute, b, '/api/contratar/servicio', { serviceId: 'visa-juvenil' })).json();
  assert.equal(view.session.eligible, false);
  const outcome = (await (await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-ok' })).json()).outcome;
  assert.deepEqual(outcome, { step: 'NOT_ELIGIBLE' });
  assert.equal(net.calls.filter(call => call.path === '/contracts').length, 0);
});

test('lead con nombre y teléfono: PUT /leads/web-<sesión>, source web, E.164 y atribución sin query', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const b = browser();
  await interview(b);
  const res = await post(leadRoute, b, '/api/contratar/lead', {
    serviceId: 'visa-juvenil', displayName: 'Ana', phone: '(305) 555-0199',
    attribution: { sourceUrl: 'https://landing.invalid/contygo-app/v7?servicio=visa-juvenil&email=a@b.c#x', utm: { utm_source: 'facebook', utm_campaign: 'sijs', evil: 'x' } },
  });
  assert.equal(res.status, 200);
  const lead = net.calls.find(call => call.method === 'PUT');
  assert.match(lead.path, /^\/leads\/web-[A-Za-z0-9_-]{16,64}$/);
  assert.equal(lead.json.source, 'web');
  assert.equal(lead.json.phoneE164, '+13055550199');
  assert.equal(lead.json.fullName, 'Ana');
  assert.deepEqual(lead.json.attribution, { sourceUrl: 'https://landing.invalid/contygo-app/v7', utm: { utm_source: 'facebook', utm_campaign: 'sijs' } });
  assert.ok(!lead.json.aiSummary.includes('menor'), 'el resumen no lleva las respuestas');
  const view = await (await post(serviceRoute, b, '/api/contratar/servicio', { serviceId: 'visa-juvenil' })).json();
  assert.deepEqual(view.session.prefill, { fullName: 'Ana', phone: '+13055550199' });
  assert.equal(view.service.partyRoles.some(role => role.roleKey === 'lead'), false, 'el titular no se pide como persona adicional');
  const bad = await post(leadRoute, b, '/api/contratar/lead', { serviceId: 'visa-juvenil', displayName: 'Ana', phone: '12' });
  assert.equal(bad.status, 400);
});

test('«Contratar» en dos pasos: código al correo, mismo cuerpo, clave nueva por intento y enlace solo en la respuesta', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const logs = captureConsole();
  try {
    const b = browser();
    const ask = await toCode(b, net);
    assert.deepEqual(ask, { step: 'ASK_CODE', maskedEmail: 'a***@gmail.com', expiresAt: '2026-09-28T15:19:05Z' });
    const first = net.calls.find(call => call.path === '/contracts');
    assert.match(first.headers['Idempotency-Key'], /^alta-[A-Za-z0-9_-]+-1-1$/);
    assert.equal(first.json.consent.channel, 'web');
    assert.equal(first.json.externalRef, net.calls.find(call => call.method === 'PUT').path.replace('/leads/', ''), 'el alta lleva el externalRef del lead');

    const wrong = (await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '000000' })).json()).outcome;
    assert.deepEqual(wrong, { step: 'WRONG_CODE', attemptsLeft: 4 });
    const right = await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481 920' });
    const outcome = (await right.json()).outcome;
    assert.equal(right.headers.get('cache-control'), 'no-store');
    assert.deepEqual(outcome, { step: 'SIGN', clientCreated: true, caseNumber: 'U26-000133', signingUrl: SIGNING_URL, serviceAlreadyLive: null, firstName: 'Ana' });

    const [, wrongCall, rightCall] = net.calls.filter(call => call.path === '/contracts');
    const { verificationId, verificationCode, ...repeated } = rightCall.json;
    assert.deepEqual(repeated, first.json, 'la 2.ª llamada repite EXACTAMENTE el cuerpo de la 1.ª');
    assert.equal(verificationId, VERIFICATION_ID);
    assert.equal(verificationCode, '481920');
    const keys = [first, wrongCall, rightCall].map(call => call.headers['Idempotency-Key']);
    assert.equal(new Set(keys).size, 3, 'cada intento estrena su Idempotency-Key');
    assert.ok(!logs.lines.some(line => line.includes('tok_SECRETO') || line.includes(VERIFICATION_ID)), 'ni la URL de firma ni el sobre llegan a los logs');
  } finally { logs.restore(); }
});

test('cliente existente: «¡Ya eres cliente!» solo tras el código, y aviso del trámite en curso', async () => {
  const net = mockFetch(); contygoDefaults(net, { existingClient: true, warnings: [{ code: 'SERVICE_ALREADY_LIVE', caseNumber: 'U26-000123' }] });
  const b = browser();
  const ask = await toCode(b, net);
  assert.equal(ask.step, 'ASK_CODE');
  assert.ok(!('clientCreated' in ask), 'la 1.ª respuesta es igual para clientes y desconocidos');
  const outcome = (await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome;
  assert.equal(outcome.clientCreated, false);
  assert.equal(outcome.serviceAlreadyLive, 'U26-000123');
  const again = (await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome;
  assert.deepEqual(again, { step: 'ALREADY_DONE', caseNumber: 'U26-000133' });
});

test('CLIENT_NEEDS_HUMAN, código caducado y 429: cada uno con su pantalla y sin bucles', async () => {
  const net = mockFetch(); contygoDefaults(net);
  let mode = 'human';
  net.on('POST', '/contracts', call => {
    if (!call.json.verificationId) return mode === 'limit'
      ? { status: 429, body: { error: { code: 'DESTINATION_RATE_LIMITED', message: '…' } }, headers: { 'retry-after': '1800' } }
      : { status: 409, body: { error: { code: 'CLIENT_VERIFICATION_REQUIRED', details: { verificationId: VERIFICATION_ID, maskedEmail: 'a***@gmail.com', expiresAt: null } } } };
    return mode === 'human' ? { status: 409, body: { error: { code: 'CLIENT_NEEDS_HUMAN', message: '…' } } } : { status: 409, body: { error: { code: 'VERIFICATION_EXPIRED', message: '…' } } };
  });
  const b = browser();
  await toCode(b, net);
  assert.deepEqual((await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome, { step: 'HUMAN' });
  assert.deepEqual((await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome, { step: 'RESTART' }, 'esa verificación ya no sirve');

  mode = 'expired';
  await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-ok' });
  assert.deepEqual((await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome, { step: 'RESTART' });
  const firstCalls = net.calls.filter(call => call.path === '/contracts' && !call.json.verificationId).map(call => call.headers['Idempotency-Key']);
  assert.match(firstCalls.at(-1), /-1-2$/, 'reiniciar tras caducar estrena la clave de la 1.ª llamada');

  mode = 'limit';
  const before = net.calls.length;
  const limited = await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-ok' });
  assert.deepEqual((await limited.json()).outcome, { step: 'RETRY_LATER', reason: 'destination', retryAfter: 1800 });
  assert.equal(limited.headers.get('retry-after'), '1800');
  assert.equal(net.calls.slice(before).filter(call => call.path === '/contracts').length, 1, 'un 429 no se reintenta');
});

test('si la persona cambia un dato tras recibir el código, empieza otra vez por la 1.ª llamada', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const b = browser();
  await toCode(b, net);
  await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm({ address: { line1: '200 Ocean Dr', city: 'Miami', state: 'FL', zip: '33139' } }), captchaToken: 'token-ok' });
  await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' });
  const calls = net.calls.filter(call => call.path === '/contracts');
  assert.equal(calls.length, 3);
  assert.equal(calls[1].json.client.address.line1, '200 Ocean Dr');
  assert.equal(calls[2].json.client.address.line1, '200 Ocean Dr', 'el código se canjea con el cuerpo nuevo');
  assert.ok(!('apartment' in calls[2].json.client.address));
});

test('un corte al confirmar: reintentar el mismo código reusa su Idempotency-Key', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const b = browser();
  await toCode(b, net);
  let cut = true;
  net.on('POST', '/contracts', call => { if (call.json.verificationCode && cut) return new TypeError('socket hang up'); return { status: 201, body: { clientCreated: true, caseId: 'k', caseNumber: 'U26-000140', contractId: 'c1', clientId: 'x', signingUrl: SIGNING_URL, warnings: [] } }; });
  const first = (await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome;
  assert.equal(first.step, 'RETRY_LATER');
  cut = false;
  const second = (await (await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' })).json()).outcome;
  assert.equal(second.step, 'SIGN');
  const keys = new Set(net.calls.filter(call => call.json?.verificationCode).map(call => call.headers['Idempotency-Key']));
  assert.equal(keys.size, 1);
});

test('CAPTCHA y límites propios delante del envío del código', async () => {
  const net = mockFetch(); contygoDefaults(net);
  process.env.TURNSTILE_SECRET_KEY = '1x0000000000000000000000000000000AA';
  const b = browser();
  await interview(b);
  const denied = await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-malo' });
  assert.equal(denied.status, 403);
  const missing = await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm() });
  assert.equal(missing.status, 403);
  assert.equal(net.calls.filter(call => call.path === '/contracts').length, 0, 'sin CAPTCHA no se envía ningún código');
  const verify = net.calls.find(call => call.url.includes('siteverify'));
  assert.equal(verify.json.secret, process.env.TURNSTILE_SECRET_KEY);
  for (let i = 0; i < 2; i++) await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-ok' });
  const limited = await post(startRoute, b, '/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-ok' });
  assert.equal(limited.status, 429, 'la sesión tiene su techo por hora');
  assert.ok(Number(limited.headers.get('retry-after')) > 0);
  const foreign = await startRoute.POST(b.request('/api/contratar/iniciar', { form: contractForm() }, { headers: { origin: 'https://evil.example' } }));
  assert.equal(foreign.status, 403);
  const noSession = await startRoute.POST(browser().request('/api/contratar/iniciar', { form: contractForm(), captchaToken: 'token-ok' }));
  assert.equal(noSession.status, 409);
});

test('webhooks: firma HMAC del cuerpo crudo, ventana de ±300 s, dedupe por X-Event-Id y efecto en la sesión', async () => {
  const net = mockFetch(); contygoDefaults(net);
  const b = browser();
  await toCode(b, net);
  const externalRef = net.calls.find(call => call.method === 'PUT').path.replace('/leads/', '');
  await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' });
  const raw = JSON.stringify({ eventId: '6f1c1d1e-0000-4000-8000-0000000000aa', type: 'contract.signed', occurredAt: '2026-09-28T10:00:00.000Z', dedupeKey: 'c', data: { caseNumber: 'U26-000133', contractId: '55555555-5555-4555-8555-555555555555', createdVia: 'web', externalRef, serviceSlug: 'visa-juvenil-basico', signedAt: '2026-09-28T10:00:00.000Z' } });
  const send = (body, { ts = String(Math.floor(Date.now() / 1000)), sig, id = '6f1c1d1e-0000-4000-8000-0000000000aa', secret = 'whsec_prueba' } = {}) => {
    const { NextRequest } = require('next/server');
    return webhookRoute.POST(new NextRequest('https://landing.invalid/api/webhooks/contygo', { method: 'POST', body, headers: { 'content-type': 'application/json', 'x-event-id': id, 'x-timestamp': ts, 'x-signature': sig ?? signWebhook(secret, ts, body) } }));
  };
  assert.equal((await send(raw)).status, 200);
  assert.equal((await send(raw)).status, 200, 'un reenvío del mismo evento responde 2xx');
  assert.equal((await send(raw, { secret: 'otro' })).status, 401);
  assert.equal((await send(raw, { ts: String(Math.floor(Date.now() / 1000) - 301) })).status, 401);
  const reformatted = JSON.stringify(JSON.parse(raw), null, 2);
  assert.equal((await send(reformatted, { sig: signWebhook('whsec_prueba', String(Math.floor(Date.now() / 1000)), raw) })).status, 401, 'la firma es de los bytes crudos');
  // contygo todavía dice «sent» (su caché), pero el aviso firmado ya llegó: manda el aviso.
  net.on('GET', /^\/contracts\/[^/]+$/, { status: 200, body: { contractId: 'c', caseId: 'k', caseNumber: 'U26-000133', status: 'sent', sentAt: null, signedAt: null, signingExpiresAt: null, downpayment: { status: 'pending', amountCents: null, paidAt: null }, externalRef } });
  const status = await (await post(statusRoute, b, '/api/contratar/estado', {})).json();
  assert.equal(status.contract, 'signed');
  delete process.env.CONTYGO_WEBHOOK_SECRET;
  assert.equal((await send(raw)).status, 503, 'sin secreto no se acepta nada; contygo reintentará');
});

test('estado sin PII y con caché de 60 s; reenvío con clave nueva y sus respuestas', async () => {
  const net = mockFetch(); contygoDefaults(net);
  net.on('GET', /^\/contracts\/[^/]+$/, { status: 200, body: { contractId: 'c', caseId: 'k', caseNumber: 'U26-000133', status: 'sent', sentAt: '2026-09-28T10:00:00Z', signedAt: null, signingExpiresAt: '2026-10-12T10:00:00Z', downpayment: { status: 'pending', amountCents: 50000, paidAt: null }, externalRef: 'web-x' } });
  let resend = 0;
  net.on('POST', /\/link$/, () => (++resend < 3 ? { status: 200, body: { contractId: 'c', signingUrl: SIGNING_URL, expiresAt: '2026-10-12T00:00:00Z', rotated: resend > 1 } } : { status: 409, body: { error: { code: 'CONTRACT_ALREADY_SIGNED' } } }));
  const b = browser();
  const none = await post(statusRoute, b, '/api/contratar/estado', {});
  assert.equal(none.status, 404);
  await toCode(b, net);
  await post(confirmRoute, b, '/api/contratar/confirmar', { code: '481920' });
  const one = await (await post(statusRoute, b, '/api/contratar/estado', {})).json();
  await post(statusRoute, b, '/api/contratar/estado', {});
  assert.deepEqual(one, { ok: true, caseNumber: 'U26-000133', clientCreated: true, contract: 'sent', signingExpiresAt: '2026-10-12T10:00:00Z', downpayment: 'pending', checkedAt: one.checkedAt });
  assert.equal(net.calls.filter(call => call.method === 'GET' && call.path.startsWith('/contracts/')).length, 1, 'no más de una consulta por minuto');

  const r1 = (await (await post(resendRoute, b, '/api/contratar/reenviar', {})).json()).outcome;
  const r2 = (await (await post(resendRoute, b, '/api/contratar/reenviar', {})).json()).outcome;
  const r3 = (await (await post(resendRoute, b, '/api/contratar/reenviar', {})).json()).outcome;
  assert.equal(r1.step, 'SIGN_LINK');
  assert.equal(r2.rotated, true);
  assert.deepEqual(r3, { step: 'ALREADY_SIGNED' });
  const keys = net.calls.filter(call => call.path.endsWith('/link')).map(call => call.headers['Idempotency-Key']);
  assert.equal(new Set(keys).size, 3);
  assert.equal((await post(resendRoute, b, '/api/contratar/reenviar', {})).status, 429, 'nuestro techo de reenvíos va por debajo del de contygo');
});

test('Gemini solo interpreta la pregunta actual: una fecha dicha con palabras se normaliza y una incompleta no avanza', async () => {
  const net = mockFetch(); contygoDefaults(net);
  let reply = { value: '2026-05-14', clear: true };
  const original = agentServer.getGenAI;
  const genai = { models: { generateContent: async () => ({ text: JSON.stringify(reply) }) } };
  Object.defineProperty(agentServer, 'agentEnabled', { value: true, configurable: true });
  agentServer.getGenAI = () => genai;
  try {
    const b = browser();
    const greeting = await (await post(intakeRoute, b, '/api/agent/service-intake', { serviceId: 'apelacion', answers: {} })).json();
    assert.equal(greeting.question.kind, 'date');
    const said = await (await post(intakeRoute, b, '/api/agent/service-intake', { serviceId: 'apelacion', answers: {}, field: ids.apelQ, answer: 'el catorce de mayo de este año' })).json();
    assert.deepEqual(said.answers, { [ids.apelQ]: '2026-05-14' });
    reply = { value: '2026-05', clear: false };
    const unclear = await (await post(intakeRoute, browser(), '/api/agent/service-intake', { serviceId: 'apelacion', answers: {}, field: ids.apelQ, answer: 'en mayo' })).json();
    assert.equal(unclear.complete, false);
    assert.match(unclear.message, /Necesito confirmar/);
  } finally { agentServer.getGenAI = original; }
});
